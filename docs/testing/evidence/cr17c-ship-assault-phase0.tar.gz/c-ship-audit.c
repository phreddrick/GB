#include <stdlib.h>
#include <string.h>
#include <math.h>
#define EXTERN
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "buffers.h"
#undef EXTERN
#include "files_shl.p"
#include "GB_server.p"
static racetype attacker, defender;
static startype star;
static long tape[8];static int ix, nt;
long random(void) { if(ix>=nt){fprintf(stderr,"unexpected draw %d\n",ix);exit(98);}return tape[ix++]; }
int notify(int p,int g,char *s) {printf("NOTICE %d/%d %s",p,g,s);return 1;}
void warn(int p,int g,char *s) {printf("WARNING %d/%d %s",p,g,s);}
void putrace(racetype *r) {printf("RACE_WRITE %d morale=%ld\n",r->Playernum,r->morale);}
char *Ship(shiptype *s) {return "#77";}
void getstar(startype **s,int n){*s=&star;}
void putstar(startype *s,int n){}
void getsdata(struct stardata *s){*s=Sdata;}
void putsdata(struct stardata *s){}
#include "c-helpers.inc"
void unload_onto_alien_sector(int,int,planettype *,shiptype *,sectortype *,int,int);
int main(int argc,char **argv){
 shiptype sh;planettype p;sectortype sec;int i,zero,partial,mil,victory,mutual;double before;
 if(argc!=2)return 2;
 zero=!strcmp(argv[1],"zero-loss-retreat");partial=!strcmp(argv[1],"partial-retreat");mil=!strcmp(argv[1],"military-retreat");victory=!strcmp(argv[1],"victory");mutual=!strcmp(argv[1],"mutual");
 if(!(zero||partial||mil||victory||mutual))return 2;
 memset(&sh,0,sizeof(sh));memset(&p,0,sizeof(p));memset(&sec,0,sizeof(sec));
 attacker.Playernum=1;defender.Playernum=2;strcpy(attacker.name,"attacker");strcpy(defender.name,"defender");attacker.fighters=victory?10:1;defender.fighters=1;attacker.mass=2;attacker.likes[1]=defender.likes[1]=1;races[0]=&attacker;races[1]=&defender;Num_races=2;Stars[0]=&star;strcpy(star.name,"Home");strcpy(star.pnames[0],"World");star.AP[0]=100;
 sh.owner=1;sh.number=77;sh.armor=1;sh.damage=0;sh.popn=zero?100:200;if(mutual)sh.popn=1;if(mil){sh.troops=200;sh.popn=0;}sh.mass=zero?210:(mutual?302:700);before=sh.mass;sh.land_x=1;
 sec.owner=2;sec.race=2;sec.condition=1;sec.mobilization=7;sec.popn=(victory||mutual)?1:100;if(mil){sec.popn=0;sec.troops=100;}
 p.info[1].numsectsowned=1;p.info[1].mob_points=7;
 for(i=0;i<8;i++)tape[i]=2147483647L;nt=6;if(zero)tape[1]=tape[3]=tape[5]=0;if(partial){tape[1]=50;tape[3]=50;tape[5]=5;}if(mil){tape[1]=50;tape[3]=500;tape[5]=50;}
 unload_onto_alien_sector(1,0,&p,&sh,&sec,mil?MIL:CIV,mutual?1:100);
 printf("RESULT case=%s mass_before=%.0f mass_after=%.0f ship=%u/%u sector=%u/%u/%u ap=%u draws=%d\n",argv[1],before,sh.mass,sh.popn,sh.troops,sec.owner,sec.popn,sec.troops,star.AP[0],ix);
 return 0;
}
