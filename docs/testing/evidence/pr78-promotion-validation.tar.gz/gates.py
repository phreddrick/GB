import subprocess,sys,pathlib,os
p=pathlib.Path(__file__).parent
checks=[('c-fixtures',['make','-C','test/ctool','check']),('inventory',['test/scripts/inventory-check.sh']),('golden-mutations',['test/scripts/golden-mutations.sh']),('golden-selftest',['test/scripts/golden-mutations-selftest.sh']),('lint-selftest',['test/scripts/lint-gate-selftest.sh']),('gate-approval-selftest',['test/scripts/gate-approval-selftest.sh']),('lint',['test/scripts/lint-gate.sh',str(p/'lint.json')]),('workflow-policy',['python3','.github/scripts/workflow_policy_check.py']),('workflow-shellcheck',['bash','-e','-c','shellcheck .github/scripts/*.sh']),('manifests',['deploy/kustomize/tests/run.sh']),('diff-check',['git','diff','--check'])]
failures=[]
for name,cmd in checks:
 r=subprocess.run(['python3',str(p/'run.py'),name]+cmd)
 if r.returncode:failures.append(name)
print('FAILED GATES:',failures,flush=True);sys.exit(bool(failures))
