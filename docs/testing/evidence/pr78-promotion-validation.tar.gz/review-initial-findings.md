# Independent initial PR78 promotion implementation review

Separate read-only reviewer. Initial source/test inspection: 2026-11-13T21:37Z–21:40Z. Source hashes are preserved in review-initial-tests.json. No publication, registry network call, workflow dispatch, image execution, live access or source edit occurred. Tests use synthetic archives/APIs/registries.

Initial 27 new regressions independently passed in0.47s wall. This did not establish final approval.

## R1 — blocking evidence-finalization finding

At the initial source revision, pr78_promotion.py wrote a journal checkpoint with status=complete,complete=true,failure=null before finalise() succeeded. Independent fault injection of finalise() OSError after fake verified uploads left no final record, but the last retained journal entry was accepted by validate_record() as complete. review-finalizer-reproduction.json preserves this exact result. CLI exit1 was correct, but the retained validator-accepted success checkpoint contradicted the reporting-failure evidence requirement. Existing regression checked only absence of final file/presence of journal and missed that condition.

Required correction: retain a distinct provisional/diagnostic journal contract; finalization failure must be explicit and must not leave a checkpoint accepted as a completed publication/promotion record. Keep confirmed remote effects visible; do not imply rollback.

## R2 — record/evidence completeness

The initial record omitted explicit expected/observed config digests promised by the design and did not bind actual scanner/database metadata. Manifest hashes cryptographically bind configs and the workflow already performs fresh scans, so no byte-substitution bypass was found. Nevertheless, a scanner-version text file alone cannot establish database identity/freshness. Require actual scanner DB metadata/hash evidence and truthful source/time distinctions, or explicitly qualify that limitation if the owner changes the requirement.

## Revision status

Author subsequently reported R1 correction using a distinct journal wrapper and explicit record_finalisation_failed checkpoint, expected/observed config fields, and promotion-only per-scan database snapshots. These reports are pending final independent source/test revalidation. Historical initial results remain unchanged; final approval will be separate.
