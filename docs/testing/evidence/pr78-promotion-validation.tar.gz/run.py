import subprocess,sys,pathlib,json,datetime,time,os
p=pathlib.Path(__file__).parent;os.umask(0o077);name=sys.argv[1];argv=sys.argv[2:];start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic();print('START '+name,flush=True)
with open(p/(name+'.log'),'x') as out:
 try:r=subprocess.run(argv,stdout=out,stderr=subprocess.STDOUT,timeout=3600);code=r.returncode
 except subprocess.TimeoutExpired:code=124
record={'command':argv,'cwd':os.getcwd(),'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'elapsed_seconds':round(time.monotonic()-t,3)};(p/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);sys.exit(code)
