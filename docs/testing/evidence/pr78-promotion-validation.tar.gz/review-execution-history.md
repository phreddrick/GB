# Independent review execution history

- Initial 27 new tests passed at21:37Z; source hashes/logs remain in review-initial-tests.*.
- Initial record-finalization fault reproduced validator-accepted complete journal without a final record. Original evidence remains review-finalizer-reproduction.json; finding R1 recorded in review-initial-findings.md.
- A later offline real-artifact compatibility attempt reused the earlier intentionally sanitized preservation api-jobs.json, which omits head_sha. The existing provenance validator correctly rejected missing job/source witnesses before archive checks. This was an inadequate local fixture attempt, not a production admission defect; no invented provenance fields were accepted or saved.
- Corrected independent compatibility validation uses freshly collected complete proof in preserved-candidate/provenance.json and exact unchanged ZIPs. It passed; review-real-artifact-admission.json records hashes/identities and explicitly makes no new network claim.
- Corrected 28 new tests passed at21:48Z; review-r5-tests.* records final tested source hashes. R1 correction was independently reproduced again and is captured in review-r1-correction.json. The distinct failed journal is rejected as a promotion record, with confirmed registry effects still visible.
- An attempted local source lookup under the standard Go module cache found no aquasecurity directory. Pinned public action/metadata primary sources were then inspected read-only to confirm cache path and JSON field casing; no software was installed.

No publication, live registry call, workflow dispatch, image execution, live database/cluster operation or source change was performed by the reviewer.
