"""Replay Phase 0 only. No production edits; all Go changes are compiler overlays.
Usage: GOTOOLCHAIN=local python3 replay-audit.py /path/to/baseline/repository
Requires Go 1.27.4, GCC, baseline test dependencies and disposable loopback tests.
Evidence remains immutable; fresh outputs/build/overlays go to a new temp directory.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

artifact = Path(__file__).resolve().parent
repo = Path(sys.argv[1]).resolve()
expected = 'b3ac84d404cc180400336f91dadb828b52c5491a'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
if head != expected:
    raise SystemExit('Refusing a different source baseline: ' + head)
env = os.environ.copy()
env['GOTOOLCHAIN'] = 'local'
version = subprocess.check_output(['go', 'version'], env=env, text=True)
if not version.startswith('go version go1.27.4 '):
    raise SystemExit('Go 1.27.4 is required: ' + version)
output = Path(tempfile.mkdtemp(prefix='gb-assault-audit-replay-'))
print('Fresh disposable output:', output, flush=True)
checks = []

def run(name, command, cwd, expected_exit=0):
    begin = time.monotonic()
    with (output / (name + '.out')).open('wb') as out, (output / (name + '.err')).open('wb') as err:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=out, stderr=err, timeout=1800)
    entry = dict(name=name, command=command, cwd=str(cwd), exit_code=result.returncode,
                 expected_exit=expected_exit, elapsed_seconds=round(time.monotonic()-begin, 3))
    checks.append(entry)
    (output/'results.json').write_text(json.dumps(checks, indent=2)+'\n')
    print(json.dumps(entry), flush=True)
    if result.returncode != expected_exit:
        raise SystemExit('Unexpected exit: '+name+' (inspect fresh logs)')

command = json.loads((artifact/'c-build.result.json').read_text())['command']
command = [arg.replace('/tmp/cr17c-ground-assault-evidence/c-move-audit', str(output/'c-move-audit'))
           if arg == '/tmp/cr17c-ground-assault-evidence/c-move-audit' else
           arg.replace('/tmp/cr17c-ground-assault-evidence', str(artifact)) for arg in command]
run('c-build', command, repo)
for name in ('civ', 'mil', 'mutual'):
    run('c-'+name, [str(output/'c-move-audit'), name], repo)
base = {
    str(repo/'go/internal/game/rand.go'): str(artifact/'audit-rand.go'),
    str(repo/'go/internal/game/ground_assault_audit_test.go'): str(artifact/'ground_assault_audit_test.go.txt'),
}
for name, extra, expression, status in (
    ('cr19-actor-prefx', {}, '^TestAssaultAudit', 1),
    ('capture-causal-probe', {str(repo/'go/internal/game/commands_move.go'): str(artifact/'audit-capture-probe.go')}, '^TestAssaultAuditCR19Capture$/military=/fence=false$', 0),
    ('ship-legacy-audit', {str(repo/'go/internal/game/commands_load.go'): str(artifact/'audit-legacy-load.go')}, '^TestAssaultAuditHostileUnload$', 0),
):
    overlay = output/(name+'-overlay.json')
    overlay.write_text(json.dumps({'Replace': {**base, **extra}}, indent=2)+'\n')
    run(name, ['go','test','-count=1','-race','-json','-overlay='+str(overlay),'-run',expression,'./internal/game'], repo/'go', status)
run('accepted-population-regression', ['go','test','-count=1','-race','-json','-run','^TestPopulation|^TestCommandFixture','./internal/commandrules','./internal/db','./internal/game'], repo/'go')
run('c-fixtures', ['make','-C','test/ctool','check'], repo)
print('Capture proof expects FOUR failing capture leaves; exit 1 alone is insufficient.')
print('Inspect named test failures and full snapshots; overlays are diagnostics, not an implementation.')
