#include <stdlib.h>
#include <string.h>
#include <math.h>
#define EXTERN
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "buffers.h"
#undef EXTERN
#include "files_shl.p"
#include "GB_server.p"
static planettype saved_planet;
static sectortype saved_sectors[6];
static startype saved_star;
static racetype attacker, defender;
long random(void) { return 2147483647L; }
int notify(int p,int g,char *s) { printf("NOTICE %d/%d %s",p,g,s); return 1; }
void warn(int p,int g,char *s) { printf("WARNING %d/%d %s",p,g,s); }
void getplanet(planettype **p,int st,int pl) { *p=malloc(sizeof(planettype)); **p=saved_planet; }
void putplanet(planettype *p,int st,int pl) { saved_planet=*p; }
void getsector(sectortype **s,planettype *p,int x,int y) { *s=malloc(sizeof(sectortype)); **s=saved_sectors[y*3+x]; }
void putsector(sectortype *s,planettype *p,int x,int y) { saved_sectors[y*3+x]=*s; }
void getstar(startype **s,int n) { *s=Stars[n]; }
void putstar(startype *s,int n) { saved_star=*s; }
void getsdata(struct stardata *s) { *s=Sdata; }
void putsdata(struct stardata *s) { Sdata=*s; }
void putrace(racetype *r) {}
#include "c-helpers.inc"
void move_popn(int,int,int);
int main(int argc,char **argv) {
 int mil=argc>1 && !strcmp(argv[1],"mil");
 int mutual=argc>1 && !strcmp(argv[1],"mutual");
 int n=mutual?1:1000;
 attacker.Playernum=1; defender.Playernum=2;
 strcpy(attacker.name,"attacker"); strcpy(defender.name,"defender");
 attacker.fighters=mutual?1:10; defender.fighters=1;
 attacker.likes[1]=defender.likes[1]=1;
 races[0]=&attacker;races[1]=&defender;Num_races=2;Sdata.numstars=1;
 Stars[0]=&saved_star;strcpy(saved_star.name,"Home");strcpy(saved_star.pnames[0],"World");saved_star.numplanets=1;saved_star.AP[0]=100;
 saved_planet.Maxx=3;saved_planet.Maxy=2;
 saved_sectors[0].owner=1;saved_sectors[0].race=1;saved_sectors[0].condition=1;saved_sectors[0].mobilization=3;
 if(mil)saved_sectors[0].troops=n;else saved_sectors[0].popn=n;
 saved_sectors[1].owner=2;saved_sectors[1].race=2;saved_sectors[1].condition=1;saved_sectors[1].mobilization=7;saved_sectors[1].popn=1;
 saved_planet.info[0].numsectsowned=1;saved_planet.info[1].numsectsowned=1;
 saved_planet.info[0].mob_points=3;saved_planet.info[1].mob_points=7;
 saved_planet.popn=mil?1:n+1;saved_planet.troops=mil?n:0;
 saved_planet.info[0].popn=mil?0:n;saved_planet.info[0].troops=mil?n:0;saved_planet.info[1].popn=1;
 Dir[0][0].level=LEVEL_PLAN;
 argn=4;strcpy(args[1],"0,0");strcpy(args[2],"6");sprintf(args[3],"%d",n);
 move_popn(1,0,mil?MIL:CIV);
 printf("RESULT %s origin=%u/%u/%u target=%u/%u/%u ap=%u morale=%ld/%ld points=%u counts=%u/%u mob=%lu/%lu totals=%lu/%lu\n",argc>1?argv[1]:"civ",saved_sectors[0].owner,saved_sectors[0].popn,saved_sectors[0].troops,saved_sectors[1].owner,saved_sectors[1].popn,saved_sectors[1].troops,saved_star.AP[0],attacker.morale,defender.morale,attacker.points[2],saved_planet.info[0].numsectsowned,saved_planet.info[1].numsectsowned,saved_planet.info[0].mob_points,saved_planet.info[1].mob_points,saved_planet.popn,saved_planet.troops);
 return 0;
}
