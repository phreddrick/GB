CR-17C #41B / CR-19 Phase 0 evidence, baseline b3ac84d404cc180400336f91dadb828b52c5491a.
No production implementation. Original C and all preexisting tracked code remain unchanged.
All database/process tests use disposable fixtures. No live service or persistent volume is accessed.
Raw outputs and result records include intentionally failing actual-dispatch capture regressions.
Go diagnostic source edits are compiler overlays ONLY; the incomplete missing-Owner-only probe is not an approved fix.
The hostile ship helper diagnostic explicitly bypasses the existing no-write guard ONLY in an external overlay.
The stock guard remains enabled and is tested separately. Do not install any overlay as production code.

Reproduce after extracting into any private directory:
  PATH=/path/to/go1.27.4/bin:$PATH GOTOOLCHAIN=local python3 replay-audit.py /path/to/baseline/worktree
Use the exact recorded baseline, writable temporary space/cache and permission for disposable actor loopback tests.
The script checks HEAD/toolchain, rebuilds the C harness, generates relocated overlays, runs all Phase0 checks,
and writes fresh results to a new /tmp/gb-assault-audit-replay-* directory without overwriting archived evidence.
No timeout flag is added to Go tests. Every actual test invocation retains the default 600-second package timeout.
A capture-regression process exit 1 is EXPECTED but is not alone proof: inspect the four named capture leaf failures.
The stock hostile-unload guard passes; the two missing-Owner probe leaves pass; all 355 accepted population/fixture
nodes pass, including 24 named real SIGKILL boundary leaves. Neither proves new assault transaction safety.

c-build-initial.err preserves the initial failed link. Other unresolved callbacks abort with99 rather than fake behavior.
The C helper bodies are verbatim extracts; private in-memory record I/O permits observation of C putsector/putplanet
boundaries. No mechanical defender exists in these execution fixtures; AFV behavior is audited separately by source.
Controlled random values are valid deterministic fixture inputs, not new production RNG semantics.
phase0-validation.json records exact commands, elapsed times, exit statuses, raw-log SHA256 and source fingerprints.
SHA256SUMS records every archived artifact except itself. The ledger is an execution history, not implementation approval.
