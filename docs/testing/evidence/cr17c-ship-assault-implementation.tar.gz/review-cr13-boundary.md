# Independent CR13 boundary investigation and correction

**No actual post-command/turn/restart ship-mass regression reproduced.** The source-only concern that a subsequent normal turn would invoke broken `doMass` was incorrect and is withdrawn. Do not include it as an observed persistence failure or use it to block or qualify this bounded transaction.

## Actual disposable actor evidence

Reviewer privately initialized an authorized planet-root Cargo ship with Popn40000,Troops30000,MaxCrew65535,owner race mass2 and mathematically coherent initial mass140002.4 (hull2.4 plus whole complement140000; no cargo/fuel/children). Explicit unload4465 satisfies original C signed capacity bounds: the departure would reduce combined complement70000 to65535. Injected valid zero-casualty draws produce a genuine repulse.

The actual actor command emits REPULSE/casualty summary and atomically persists the unchanged whole complement and mass, race results and required durable news/inbox. Complete actor/store proposed-record agreement is asserted. Mass140002.4,Popn40000,Troops30000 remain exactly equal in actor and store through **before command, after command, movement segment, full update and orderly shutdown/restart**, with engineSERVING at all five captures. All complete durable record and actor-world SHA256 identities are in review-cr13-state-summary.json; evolving hashes across turns are legitimate schedule/world changes, not treated as immutable snapshots. Raw stage evidence and actual responder text are in review-cr13-corrected.jsonl.

Fresh corrected command: `GOTOOLCHAIN=local GOCACHE=/tmp/cr17c-habitat-cache /tmp/gb-go1274-evidence/go/bin/go test -count=1 -race -json -overlay=/tmp/cr17c-ship-assault-implementation-evidence/review-cr13-overlay.json -run '^TestReviewerCR13ExistingTurnBoundary$' ./internal/game`, exit0,game3.419s. It uses only private test overlay/disposable worlds, no production source change.

## Separate existing helper defect

Before any assault, calling existing `doMass` on a PRIVATE COPY of that ship computes8930.4 because Go's `ship.Popn+ship.Troops` wraps atuint16 (70000→4464), while original C promotes the sum. The helper's source matches baseline byte-for-byte. This proves the local arithmetic defect is pre-existing and independent of the new command.

However, search of current production Go source shows **no callers of doMass except its own recursion**. Normal update/segment code does not invoke it. The actual command/turn/restart experiment confirms persisted mass is preserved, so it would be false to state that normal turns now flush the helper's wrapped mass. CR13 and general legacy mass/turn implementation remain open without falsely claiming closure or inventing a new regression. Existing #41A/NewR3 guards reject genuinely deficient complete-body preimages when encountered; no repair or overcapacity gameplay restriction was introduced.

## Honest failed investigation history

The first test expected to observe underfloor mass after a normal turn and failed because that expected regression did not occur. A second diagnostic run printed all actual stages and failed the same incorrect expectation. Both outputs and original test variants remain preserved (`review-cr13-boundary.*`, `review-cr13-diagnostic.*`, initial/diagnostic .go.txt sources). The corrected final probe asserts the genuinely observed persistence and distinguishes the copied-helper observation; it does not suppress a real production failure or remove any permanent test.

## Review disposition

The new immediate atomic operation preserves the approved C bounds, returning complements, whole-body mass, records and effects. This extended real-dispatch test also preserves them through current turns and restart. There is **no blocking finding from this CR13 investigation**. Do not downgrade an actual new partial-write defect to a qualification; none was found here. The broader dormant mass-helper/turn integration problem remains a separate CR13/CR11 concern, not completed by this work. No schema, gameplay, source, gate, live database or other worktree change occurred.
