# Independent ship-assault review: initial pure rules

Baseline 7a17a1bc7edf75091386f30944a529a0ccf48d8d. Read-only review; production code is still being written by the author. This is NOT implementation approval.

The owner-approved survivor refund resolves the historical Phase0 mass blocker. Initial pure rules preserve selected-ship/governor authority (not movement star-governor/slavery policy), use caller race mass, zero AP, C ship-specific attack factors `(Armor+1)*(2-Damage/100)`, fixed pre-casualty scale and military integer division ordering. Defender elimination, repulse, neutral mutual destruction and empty occupation are separated before absorption. Absorption samples original body pools before capacity saturation and never resurrects a dead party. Complete planet accounting is checked before and recalculated after; no unrelated repair occurs. Current result mass is M-Q*m except repulse M-casualties*m, with finite/nonnegative checks. Selected proposal is deep-owned through JSON; race/planet embedded values have value arrays except copied sector slice.

Original C inspected: source/load.c unload_onto_alien_sector and signed/default limits, source/move.c ground_attack, current population dispatcher, ship/race model and mechanical predicates. The original C retreat sign defect, unlike carrier treatment, is explicitly rejected by owner and not reintroduced. C helper already assigns captures; no historical movement missing-assignment claim applies to ship path.

Initial precision notes, not new gameplay blockers:

- Current request Amount0 represents both omitted and explicit zero. That matches C default expansion only when the checked complement becomes a valid positive party. Empty force must refuse. Documentation and tests must state explicit-zero handling accurately; no negative/reverse or hostile load may reach the legacy writer.
- Bound-before-default and pre-default VN rule ordering must remain intact, including overcapacity fixtures; do not silently impose a new blanket VN ban.
- Mechanical exclusion currently follows PR78's current-Go planet-root landed predicate, including peer-docked root AFVs. It must retain full original root list/alliance witnesses; selected ship root identity must also be checked independently by storage.
- Need future final-source review of persistent ship+planet+both-races+news+telegram+sequence participation, immutable AP/root witnesses, commit uncertainty, actor install and buffered output. These do not yet exist at this first inspection.

Fresh compile/regression command: `GOTOOLCHAIN=local GOCACHE=/tmp/cr17c-habitat-cache /tmp/gb-go1274-evidence/go/bin/go test -count=1 ./internal/commandrules`, exit0, package0.016s. Existing pure rule tests passed; this does not substitute for new ship tests or final acceptance. No live or unrelated worktree operation occurred.
