import subprocess,pathlib,json,os,time,hashlib
r=pathlib.Path('/tmp/GB-cr17c-ship-ground-assault');e=pathlib.Path(__file__).parent/'negative-controls-clock-final';e.mkdir(exist_ok=True)
rules='go/internal/commandrules/ship_assault.go';db='go/internal/db/ship_assault.go';dispatch='go/internal/game/population_command.go'
rs=(r/rules).read_text();ds=(r/db).read_text();ps=(r/dispatch).read_text()
controls=[
('duplicate-survivor-mass',rules,rs.replace('selected.Mass = sh.Mass - float64(removed)*a.Mass','selected.Mass = sh.Mass - float64(removed)*a.Mass\nif c.Outcome=="REPULSE" { selected.Mass-=2*float64(departing-c.AttackerLoss)*a.Mass }'), './internal/commandrules','^TestShipAssaultExactCSemantics/C_partial$','strength/casualty/refund'),
('split-world-write',db,ds.replace('if e = s.metaFault("ship-assault.before"); e != nil {','if e = s.db.Update(func(tx *bolt.Tx)error{return tx.Bucket(prepared.writes[0].bucket).Put(prepared.writes[0].key,prepared.writes[0].after)});e!=nil{return outcome,e}\nif e = s.metaFault("ship-assault.before"); e != nil {'), './internal/game','^TestShipAssaultActorFaults/ship-assault.before/false$','aborted write persisted'),
('incorrect-capture',rules,rs.replace('to.Owner = uint8(player)','to.Owner = 0'),'./internal/commandrules','^TestShipAssaultExactVictory$','defined C victory/accounting'),
('missing-news',db,ds.replace('if e := s.metaFault("ship-assault.before-commit"); e != nil {','if e:=tx.Bucket(BucketNews).Delete(prepared.checks[len(prepared.checks)-2].key);e!=nil{return e}\nif e := s.metaFault("ship-assault.before-commit"); e != nil {'),'./internal/game','^TestShipAssaultGameplayAndMass/military=false/victory$','incomplete or unrelated durable mutation'),
('missing-telegram',db,ds.replace('if e := s.metaFault("ship-assault.before-commit"); e != nil {','if e:=tx.Bucket(BucketTelegrams).Delete(prepared.checks[len(prepared.checks)-1].key);e!=nil{return e}\nif e := s.metaFault("ship-assault.before-commit"); e != nil {'),'./internal/game','^TestShipAssaultGameplayAndMass/military=false/victory$','incomplete or unrelated durable mutation'),
('legacy-hostile-fallback',dispatch,ps.replace('if s.handleShipGroundAssault(p, g, uint32(id), request, sess) {','if false && s.handleShipGroundAssault(p, g, uint32(id), request, sess) {').replace('s.runPopulation(p, g, uint32(id), request, sess)','return false'), './internal/game','^TestShipAssaultGameplayAndMass/military=false/victory$','complete actor assault proposal differs')]
results=[]
env=os.environ.copy();env.update(GOTOOLCHAIN='local',GOCACHE='/tmp/cr17c-habitat-cache')
for name,path,src,pkg,pattern,needle in controls:
 assert src!=(r/path).read_text(),name
 file=e/(name+'.go.txt');file.write_text(src);overlay=e/(name+'-overlay.json');overlay.write_text(json.dumps({'Replace':{str(r/path):str(file)}}))
 cmd=['/tmp/gb-go1274-evidence/go/bin/go','test','-count=1','-overlay='+str(overlay),'-run',pattern,pkg];started=time.time();p=subprocess.run(cmd,cwd=r/'go',env=env,capture_output=True)
 (e/(name+'.out')).write_bytes(p.stdout);(e/(name+'.err')).write_bytes(p.stderr)
 ok=p.returncode==1 and needle in p.stdout.decode() and 'build failed' not in p.stdout.decode() and 'syntax error' not in p.stderr.decode()
 result={'name':name,'command':cmd,'exit':p.returncode,'intended_assertion':needle,'detected':ok,'seconds':time.time()-started,'source_sha256':hashlib.sha256(file.read_bytes()).hexdigest()};results.append(result);print(name,ok,flush=True)
(e/'negative-controls.json').write_text(json.dumps(results,indent=2)+'\n')
if not all(x['detected'] for x in results):raise SystemExit(1)
