# Independent ship-assault implementation review, round 1

Status: no blocking runtime defect found in current source; final approval pending independent-value permanent tests and complete final-source evidence/gates. This does not approve deployment, full #41/#51 acceptance, or an unexecuted complete suite. No repository files were edited by the reviewer.

## Reviewed source and operation

Inspected commandrules/ship_assault.go, db/ship_assault.go, game/ship_assault_command.go, population dispatcher diff, new game/db/crash tests, original load.c/move.c and accepted command/effects infrastructure. Source SHA256 identities are in review-round1-source.json.

The accepted strict population selector/parser intercepts the entire c/m request before legacy mutation. The new classifier selects only foreign planet sectors and remains within staged validation on illegal amounts/authority; nonhostile operations retain #41A. No selected foreign ship authorization, mechanical volley, automatic transporter or legacy undock repair can run in the new handler. Missing/cyclic/inconsistent actor context is refused/halted without a write.

Pure rules independently derive the quantity with C bound-before-default/VN ordering, selected-ship governor authority, exact planet root membership and complete third-party alliance witnesses. Armor/damage inputs are ship-specific; military factors and integer division precede floating ratios as C. Outcome precedes absorption; checked accounting covers all embedded sectors and complete owner/global totals. Approved mass refund is net casualty mass on repulse; all departing mass otherwise. AP/star is immutable.

Storage writes selected ship, complete planet and both races, checks full preimages including immutable star/root/alliance witnesses inside the same Tx, replays/revalidates proposals, and calls mandatory existing news+inbox+sequence allocation before commit. New method does not broaden older closed operation contracts. Failed writes/panics before Tx closure roll back all participants; commit-report error remains uncertain with shared guard and diagnostic-only readback. Reporting errors after confirmed commit stay committed. No new schema/bucket/commit kind or fresh storage RNG.

Actor installs only confirmed results after collectively checking identity/preimages; preserves ship/race/planet addresses and embedded sector slice. Success/casualty output and registry hints follow coherent installation; no warn/pushTelegram duplicates. Installation/uncertainty/reporting failures HALT and suppress stale shutdown flush. Ordinary unavailable online hint remains best-effort and durable inbox persists.

## Fresh independent execution

`GOTOOLCHAIN=local GOCACHE=/tmp/cr17c-habitat-cache /tmp/gb-go1274-evidence/go/bin/go test -count=1 -race -json -run '^(TestShipAssault|TestShipGroundAssault)' ./internal/game ./internal/db ./internal/commandrules`

Exit0;167 passed nodes/159 leaves, including24 real civilian/military SIGKILL cases. Raw JSONL/stderr/result in review-round1-tests.*. All original accepted tests remain unchanged in the inspected diff; their full final execution is the author's later gate requirement. These are actual child process SIGKILL boundaries and full durable record/metadata/sequence comparison, followed by reopen/segment/update, not panic substitutes.

Reviewer-authored independent exact-value semantics overlay: `go test -count=1 -race -json -overlay=/tmp/cr17c-ship-assault-implementation-evidence/review-semantics-overlay.json -run '^TestReviewerShipExactSemantics$' ./internal/commandrules`, same Go1.27.4 environment. Exit0,3 passed nodes. Exact assertions: equal strength200/200 gives50/50 civilian losses, returned complement150,mass600; Armor4/Damage50 gives strength375,losses26/93,complement174,mass648. Also exact race morale/Points/Translate, ownership/mob/pop totals, no-loss210-mass refund, overcapacity default/explicit behavior, unchanged AP0, caller-selected-governor authority without movement-only star governor/slavery checks, input immutability. Source is review_semantics_test.go.txt.

Causal strength control: replace only ship armor/damage factors with terrain factors in a private source overlay. Exit1 at intended `strength/casualty/refund` assertion in `armor_damage` case, with no compiler/environment error. Default equal-factor fixture still passes, showing why independent nondefault geometry assertions matter. Raw logs/result and intentional source overlay are preserved; production source is unmodified.

## Findings

R1 — test effectiveness gap (must address before final acceptance): most initial actor gameplay scenarios compute expected values with the same PlanShipAssault function that production uses. Existing no-loss/partial/mutual fixed assertions are useful but do not independently verify all C strength/outcome/race/accounting/default values. The reviewer exact-value overlay and wrong-strength control demonstrate this gap. Add equivalent permanent independent expected-value rule tests, including exact casualty strengths, Points/Translate and accounting, plus declared C defaults and absorption bounds. This is a verification finding, not a demonstrated runtime defect; resolve it and retest final source.

R2 — minor comment precision: ship rules retain the copied comment “C uses origin + surviving party”; the actual ship code correctly tests destination residents+party, as load.c. Update the comment to avoid confusing the movement and ship extinction-learning predicates.

Final independent review must inspect R1/R2 disposition, six mandatory negative controls, complete normal/race/long suites, all44 retained plus24 new SIGKILL cases, unchanged gates/security checks, exact final hashes, and documentation accuracy. No new owner gameplay or architecture blocker was discovered in this review.
