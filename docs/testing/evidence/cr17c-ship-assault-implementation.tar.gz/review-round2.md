# Independent ship-assault review: round 2

Source/test review verdict: **no blocking findings; R1 and R2 resolved**. Final overall acceptance remains pending final documentation and complete gate evidence at the same source identity. This is independent read-only review, not deployment authorization or full #41/#51 acceptance.

## Source binding

Baseline 7a17a1bc7edf75091386f30944a529a0ccf48d8d. All10 operation source/test files recorded in review-final-source-before.json matched review-final-source-after.json after the independent executions. Additional unchanged command/effects/workspace/turn infrastructure, original C inputs and module files are bound in review-round2-source.json. Canonical sorted source-map identity: `6fd38826a46619fc3fd4b197b71401b7abcb0906be5671bd607cdfc896199a53`.

## Correction dispositions

R1 fixed: permanent commandrules/ship_assault_test.go now includes independent exact C partial and nondefault Armor/Damage results, race Points/morale/Translate, global/owner populations and mobilization/ownership totals, selected-authority distinction, C bound-before-default, zeroAP, exact victory, invalidmass and bodypool65536 saturation assertions. The original all100 survivors/no-loss example permanently asserts mass210, complement100 rather than C's negative190. These no longer rely only on PlanShipAssault as their own gameplay oracle.

R2 fixed: extinction-learning comment identifies landing-sector residents plus surviving party, correctly distinct from sector-origin C rules.

The two historical positive-hostile-unload regression expectations were appropriately migrated: formerly blanket-refused supported inputs now must actually execute and match complete actor world, durable records/metadata/effect sequences, and zero volatile aggregate counter. Frozen time and injected draws make the expected durable text exact. All unrelated prior rejection scenarios remain, and no assertions or gate tooling were weakened. Phase0 refusal results remain historical evidence rather than being retroactively rewritten.

## Fresh independent final-focused execution

Command (Go1.27.4,GOTOOLCHAIN=local,GOCACHE=/tmp/cr17c-habitat-cache):

`go test -count=1 -race -json -run '^(TestShipAssault|TestShipGroundAssault|TestGroundAssaultActorOutcomesAndRefusals|TestPopulationAuthorityForeignAndAssaultBoundary)' ./internal/game ./internal/db ./internal/commandrules`

Exit0;227 passed nodes/216 leaves;26 new real SIGKILL leaves. Game29.558s,db2.312s,rules1.045s. Raw review-final-focused.jsonl/.err and result JSON preserve actual execution. The additional2 kills independently cover before actor installation for both civilian and military; original24 new boundary cases remain. Every kill checks the actual process signal and old-or-new complete world, message, metadata and sequence state after reopening, plus later segment/update agreement. Existing44 prior SIGKILL cases are not counted as executed by this focused command; the author's full suites must preserve/execute them.

Independently reran all six causal controls using a private copy of the author's control driver and separate review-negative-controls/ outputs. Every control returned exit1 for the intended runtime assertion, with no compilation/environment failure:

1. Duplicate survivor subtraction: exact casualty/refund assertion.
2. Split selected-ship write before the transaction: aborted-write full-store comparison.
3. False capture/ownership: defined C victory/accounting assertion.
4. Omitted news: complete durable record comparison.
5. Omitted defender telegram: complete durable record/sequence comparison.
6. Real legacy fallback: complete actor assault proposal mismatch after executing actual legacy writer.

The first author's legacy control's expected-needle mismatch is preserved separately; it is not silently presented as a pass. The final control recognizes the actual intended actor mismatch, which the independent rerun reproduces. Wrong ship-strength factor control from round1 is an additional effective independent test and remains preserved.

Reviewer-authored direct-storage alliance witness probe (review_alliance_test.go.txt + review-alliance-overlay.json): two race-enabled leaves pass,db1.111s. A mutually allied third-party root AFV (including peer-docked WhatDestSHIP, relevant current-Go landed predicate) permits the nonmechanical assault and preserves the read-only ship. Altering that third party's stored diplomacy at the pretransaction boundary returns CommandStale/NOT_COMMITTED, without selected-ship/planet writes or news/inbox records. This independently confirms alliance witnesses participate, rather than simply omitting inconvenient defenders. No production helper or schema was modified.

## Complete reviewed guarantees and limits

Reviewed owner-approved mass and general outcome rules, original ship armor/damage strength and C draw order, zeroAP witnesses, positive/default and forbidden reverse grammar, exact selected authorization, mechanical/transporter exclusion, complete four-world-record plus required news/inbox/sequence Tx, repeated pure validation inside Tx, unchanged read-only root/alliance/StarAP preimages, no actor proposal installation before confirmed commit, stable object/sector identity, buffered success and live notifications, uncertain shared guard and no stale shutdown flushing. Invalid or deferred c/m never falls back to legacy. No new schema, commit kind, durable RNG, retry protocol or outbox.

Live notification unavailability is best-effort after committed inbox persistence; panics or failed success response do not reverse committed state and HALT conservatively. Text commands remain non-idempotent without durable command IDs. Ship-origin and sector-origin contracts remain separate; mechanical defense, transporters, hostile reverse/loading and unrelated command persistence remain deferred. CR11/13/20 and broader CR17/#41/#51 are not declared resolved.

No remaining source correctness issue found in this reviewed bounded implementation. Final overall acceptance requires matching final full normal/exact race/long-race/golden/mutation/security/gate results and accurate final documentation; this round does not invent those still-in-progress results. All independent test mutations remained in disposable stores/private overlays. No live systems or unrelated worktrees changed.
