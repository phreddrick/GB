import json,pathlib,collections
p=pathlib.Path(__file__).parent
summary={}
for name in ['normal','normal-final','accepted-normal-inventory','accepted-long-race','clock-final-normal-inventory','clock-final-long-race']:
 f=p/(name+'.out')
 if not f.exists() or not(p/(name+'.result.json')).exists():continue
 rows=[]
 for line in f.read_text().splitlines():
  try:x=json.loads(line)
  except:continue
  if isinstance(x,dict):rows.append(x)
 tests=[x for x in rows if x.get('Test') and x.get('Action') in ['pass','fail','skip']];parents={(x['Package'],'/'.join(x['Test'].split('/')[:i])) for x in tests for i in range(1,len(x['Test'].split('/')))};leaves=[x for x in tests if (x['Package'],x['Test']) not in parents]
 summary[name]={'pass_nodes':sum(x['Action']=='pass' for x in tests),'fail_nodes':sum(x['Action']=='fail' for x in tests),'skip_nodes':sum(x['Action']=='skip' for x in tests),'leaves':len(leaves),'packages':{x['Package']:x.get('Elapsed') for x in rows if x.get('Action')=='pass' and not x.get('Test')},'new_ship_SIGKILL':sum(x['Test'].startswith('TestShipGroundAssaultRealProcessCrash/') and x['Action']=='pass' for x in leaves),'retained_population_SIGKILL':sum(x['Test'].startswith('TestPopulationRealProcessCrash/') and x['Action']=='pass' for x in leaves),'retained_ground_SIGKILL':sum(x['Test'].startswith('TestGroundAssaultRealProcessCrash/') and x['Action']=='pass' for x in leaves)}
(p/'test-counts.json').write_text(json.dumps(summary,indent=2)+'\n')
for name,v in summary.items():print(name,{k:v[k] for k in v if k!='packages'},'game',v['packages'].get('github.com/phreddrick/GB/go/internal/game'))
