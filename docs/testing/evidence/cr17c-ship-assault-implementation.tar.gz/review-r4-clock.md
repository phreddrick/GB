# Independent review R4: converted population test clock nondeterminism

**R4 was blocking validation stability and is now corrected in source.** Complete final-source suites still need to bind to the corrected test. This finding is not a demonstrated world transaction defect.

Fresh independent post-R3 race execution failed naturally at `TestPopulationAuthorityForeignAndAssaultBoundary/m/hostile_unload`: the complete durable-record expectation mismatched even though command execution and complete actor proposal assertions passed. Raw `review-post-r3-focused.jsonl/.err` preserve that actual failure; it must not be hidden by successful author runs or later reruns.

Root cause: the newly authorized positive historical population case independently prepares expected combat news/inbox text, then actually dispatches the command under an unfrozen wall clock. A one-second boundary between those preparations changes only the message timestamps and falsely reports incomplete persistence. New ship fixtures and the converted ground case already froze their private clock, but this converted population case did not.

## Deterministic causal evidence

An initial private diagnostic explicitly moved only the fixture clock forward2seconds after expected preparation. Both c/m cases failed, with exact row differences confined to news/inbox timestamps; all world records matched. Those `review-pop-clock-shift.*` artifacts are preserved, but this intentionally overriding clock is only a diagnosis, not the after-fix effectiveness control.

The stronger before/after control installs an upstream fixture clock before the case's own setup callback and advances its backing value by2seconds after expected preparation. It does not override the fixture callback's final clock function. Before the correction, actual dispatch observes the changed upstream value: both c/m cases exit1 at the intended complete-record assertion. Printed redacted differences show only existing news/inbox text prefixes changed2seconds, with identical outcome/casualty text. No other differing record keys were printed. Original source is frozen in review-pop-clock-before.go.txt; deterministic altered source and command/output are review-pop-upstream-before*.

Author correction captures now once inside the private actor callback and installs a constant per-fixture state.now function before independently preparing and dispatching the assault. The same upstream-clock shift then cannot change that fixture's expected/actual message timestamp. The complete durable assertion is unchanged; no timestamp normalization, output deletion, global clock/environment change or assertion weakening is used. Production semantics and timeouts are untouched.

Fresh after-fix command, Go1.27.4/GOTOOLCHAIN=local/GOCACHE=/tmp/cr17c-habitat-cache:

`go test -count=5 -race -json -overlay=/tmp/cr17c-ship-assault-implementation-evidence/review-pop-upstream-after-overlay.json -run '^TestPopulationAuthorityForeignAndAssaultBoundary/[cm]/hostile_unload$' ./internal/game`

Exit0: all10 c/m leaf executions passed across5 repetitions, including full actor and every durable record/effect-sequence comparison. Raw JSONL/stderr and result JSON preserve exact durations. Test variants, original naturally occurring failure and deterministic before failures remain archived; the independent reviewer did not edit repository files.

## Disposition

R4 source correction and causal effectiveness are independently verified. Final overall APPROVE remains pending complete accepted-source gate evidence after this final test-only correction. Earlier d275 full-suite successes are provisional historical evidence, not final source binding. No protection is weakened and no unrelated worktree/live system is modified.
