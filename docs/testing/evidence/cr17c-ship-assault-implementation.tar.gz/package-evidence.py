from pathlib import Path
import json,hashlib,tarfile,shutil,re
r=Path('/tmp/GB-cr17c-ship-ground-assault');e=Path(__file__).parent;out=r/'docs/testing/evidence'
report=e/'review-final.md'
text=report.read_text()
assert 'APPROVE FOR PR' in text and '5ed07fe6' in text,'independent final verdict/source missing'
source=json.loads((e/'clock-final-source-manifest.json').read_text())
for f,h in source.items():assert hashlib.sha256((r/f).read_bytes()).hexdigest()==h,f
shutil.copyfile(report,out/'cr17c-ship-assault-implementation-review.md')
ledgerpath=out/'cr17c-ship-assault-implementation-validation.json';v=json.loads(ledgerpath.read_text())
v['status']='PASS: BOUNDED LOCAL ACCEPTANCE AND INDEPENDENT REVIEW; hosted CI pending PR'
v['independent_review']={'verdict':'APPROVE FOR PR','file':'docs/testing/evidence/cr17c-ship-assault-implementation-review.md','sha256':hashlib.sha256(report.read_bytes()).hexdigest(),'history':['review-initial.md','review-round1.md','review-round2.md','review-r3.md','review-cr13-boundary.md','review-r4-clock.md','review-final.md']}
(e/'validation-final-before-archive.json').write_text(json.dumps(v,indent=2)+'\n')
(e/'README.txt').write_text('CR17C hostile ship-unload implementation evidence. Final code/test/gate canonicalSHA2565ed07fe6dc61cc201634feb4a2127b9642338b94d79ae975e0ecf39fcfa25dc6; baseline7a17a1b. Phase0 separate archive remains unchanged. Includes raw historical failures, corrected final commands/results, independent review rounds, source maps, private intentional-defect overlays, massfloor/clock/CR13 diagnostics. All runtime worlds disposable. No production fault endpoints, schema/outbox/command IDs or live operations. No binary artifacts included. Controls .go.txt are deliberately defective evidence, not production code. commands use absolute historical worktree/tool paths; adapt paths when replaying elsewhere. Final private TMPDIR is under this worktree ignored test/ctool/obj/tmp to avoid invalid host /tmp/.git VCS discovery; no stamping flags/gates weakened.\n')
allowed={'.json','.jsonl','.md','.py','.txt','.out','.err','.exit','.sha256','.patch','.diff','.log','.go','.c'}
files=sorted(p for p in e.rglob('*') if p.is_file() and p.suffix in allowed and p.name!='SHA256SUMS')
# No bcrypt encodings or JWT tokens may enter committed evidence.
patterns=[re.compile(rb'\$2[aby]\$[0-9]{2}\$[./A-Za-z0-9]{53}'),re.compile(rb'eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}')]
for p in files:
 b=p.read_bytes();assert not b.startswith(b'\x7fELF'),p;assert not any(x.search(b) for x in patterns),f'credential candidate: {p.name}'
manifest={str(p.relative_to(e)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(e/'SHA256SUMS').write_text(''.join(h+'  '+name+'\n' for name,h in manifest.items()))
archive=out/'cr17c-ship-assault-implementation.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in files+[e/'SHA256SUMS']:t.add(p,arcname=str(p.relative_to(e)))
with tarfile.open(archive) as t:
 for name,h in manifest.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==h,name
v['evidence_archive']={'file':str(archive.relative_to(r)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(manifest)+1,'bytes':archive.stat().st_size,'internal_sha256_manifest_verified':True}
v['archived_artifacts_sha256']=manifest
ledgerpath.write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps(v['evidence_archive']))
