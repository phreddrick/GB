Implements the next bounded #41/#51 slice: one authorized, planet-landed `unload #N c|m [amount]` can resolve a nonmechanical hostile assault without split ship/planet/race/message writes. References #38, #41 and #51; none is automatically closed.

The separate closed ship-assault contract preserves C ship Armor/Damage strength and quantity/default ordering, owner-approved survivor mass refunds, zero AP, approved capture/repulse/neutral mutual destruction and bounded absorption. It rejects inconsistent complete onboard mass and population accounting. Private proposals and a checked bounded random transcript are independently replayed inside one bbolt transaction, writing ship, complete planet, both races, combat news and defender telegram/allocation. Star/AP and complete orbital/alliance context remain read-only. Confirmed commits install into stable actor objects before output; uncertainty or installation/reporting failure fails closed without stale shutdown flushing.

Mechanical defenders, targeted transporters, hostile load/reverse forms and multi-ship selectors remain refused. Existing #41A noncombat and PR78 sector movement contracts remain separate. No schema, bucket, CR18 commit-kind, RNG-state, command-ID, outbox, authentication or deployment changes.

Validation, failure history, original-C parity/deviation, source/output SHA-256 ledger and independent review are in `docs/testing/cr17c-ship-ground-assault.md` and its evidence archive. Phase0 evidence is preserved unchanged. Independent review corrections added exact strength/accounting oracles and complete body-mass checks; no accepted assertions or allowances were weakened.

Final local acceptance uses Go1.27.4 and GOTOOLCHAIN=local:

- Full normal/inventory:4981 pass nodes,4770 passed leaves,2 existing long-test opt-in skips,0 failures.
- Exact `go test -count=1 -race ./...`:PASS, game373.123s. Complete long race:4983 pass nodes,4772 leaves,0 skips/failures (game345.003s). The600s deadline is unchanged; local margin37.8%/42.5% is not a hosted-reliability guarantee.
- 70 real SIGKILL leaves per full suite:26 new ship and all44 accepted population/ground cases.
- Six compiled private defects fail their intended mass/atomicity/ownership/news/inbox/legacy-fallback assertions; independent expected-value combat oracles and the deterministic clock control are retained.
- Build/gofmt/vet, modules/tidy, strict govulncheck, all15 C/golden mutations, inventory, lint/growth/self-tests, workflow/helper checks and offline manifests PASS. Lint remains1000 matching findings, no new/stale allowances.

Independent review corrected and revalidated whole-body mass consistency and a converted test's private timestamp clock. Failed provisional executions, causal controls and all review rounds remain archived. The source-only CR13 turn-mass prediction did not reproduce: real overcapacity repulse/segment/update/restart remained correct; the buggy old helper is dormant. No broad CR11/CR13 fix or issue closure is claimed.

Hosted CI must pass all seven jobs; no merge/deployment is authorized.

Acknowledgment policy: lint baseline and known-defect allowances unchanged; no protected tooling changes. Growth gate passed with no simulated labels. No maintainer acknowledgment labels are required for this diff.

Independent final verdict: **APPROVE FOR PR**, no blocking findings. Reviewer independently verified all440 source hashes, all9 required final gate records and raw output identities, all70 kill leaves, all15 mutations, and six intended causal failures. Review SHA256231a309f4abbea4224beb6c1c9909daa547a884eaabacdb1e56e1de2c6459269; full review/history and hashed archive accompany the implementation record.

No merge, deployment, image publication, live database or live cluster operation occurred.
