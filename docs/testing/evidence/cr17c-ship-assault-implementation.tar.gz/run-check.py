import subprocess,time,json,sys,os,pathlib,hashlib
root=pathlib.Path('/tmp/GB-cr17c-ship-ground-assault');e=pathlib.Path(__file__).parent
name,cwd,cmd=sys.argv[1:4];env=os.environ.copy();env.update({'PATH':'/tmp/gb-go1274-evidence/go/bin:/tmp/claude-1026/-home-steve-workspace-GB/ee9ebf80-502c-4ecf-ad67-736e8673c55c/scratchpad/p2c/bin:'+env.get('PATH',''),'GOTOOLCHAIN':'local','GOCACHE':'/tmp/cr17c-habitat-cache'})
env['TMPDIR']='/tmp/GB-cr17c-ship-ground-assault/test/ctool/obj/tmp'
pathlib.Path(env['TMPDIR']).mkdir(parents=True,exist_ok=True)
def source_identity():
 files=subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','go','source','test','.github','deploy'],cwd=root,text=True).splitlines()
 manifest={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in sorted(set(files)) if (root/f).is_file()}
 return hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
before=source_identity()
start=time.time()
with (e/(name+'.out')).open('wb') as out,(e/(name+'.err')).open('wb') as err:
 p=subprocess.run(['bash','-o','pipefail','-c',cmd],cwd=root/cwd,env=env,stdout=out,stderr=err)
v={'source_before':before,'source_after':source_identity(),'name':name,'cwd':str(root/cwd),'command':cmd,'exit':p.returncode,'duration_seconds':time.time()-start,'GOTOOLCHAIN':'local','go':'go1.27.4','TMPDIR':env['TMPDIR'],'outputs':{x:hashlib.sha256((e/(name+'.'+x)).read_bytes()).hexdigest() for x in ['out','err']}}
(e/(name+'.result.json')).write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v));sys.exit(p.returncode)
