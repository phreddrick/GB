package db
import (
 "testing"
 "github.com/phreddrick/GB/go/internal/model"
 bolt "go.etcd.io/bbolt"
)
func TestReviewAssaultPreservesExistingNews(t *testing.T) {
 s, _, in := assaultStoreFixture(t)
 e := s.db.Update(func(tx *bolt.Tx) error {
  b := tx.Bucket(BucketNews)
  if e := b.Put(NewsKey(model.NewsCombat,1), []byte("prior")); e != nil { return e }
  return b.Put(append(NewsKey(model.NewsCombat,2), byte(0)), []byte("malformed"))
 })
 if e != nil { t.Fatal(e) }
 out,e := s.CommitGroundAssault(in)
 t.Logf("outcome=%s err=%v",out,e)
 e = s.db.View(func(tx *bolt.Tx) error {
  got := string(tx.Bucket(BucketNews).Get(NewsKey(model.NewsCombat,1)))
  if got != "prior" { t.Fatalf("existing combat news overwritten: %q",got) }
  return nil
 })
 if e != nil {t.Fatal(e)}
}
