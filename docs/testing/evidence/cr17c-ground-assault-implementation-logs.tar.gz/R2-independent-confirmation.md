# R2 — independent confirmation of mechanical-peer exclusion defect

Discovery: parent implementer during final helper reconciliation; independently confirmed by separate read-only reviewer `/root/assault_phase0_review`. This finding supersedes the prior provisional statement that no source blockers remained. Earlier review reports are preserved unchanged, not rewritten as if this had been caught sooner. I missed this C/Go landed-helper distinction in the earlier source reviews.

## Exact cause

Current Go `game/planet.go:1373` defines landed as `ship.Docked && ship.WhatOrbits == model.LevelPlan`. `game/commands_move.go` mechDefend calls this helper for a foreign AFV at the destination with ammunition, crew, guns, retaliation and nonmutual alliance. It does not require WhatDest==LevelPlan.

The new assault rules initially added an extra `sh.WhatDest == model.LevelPlan` requirement. A live foreign AFV in the complete planet root chain may be reciprocally docked to another root ship (`WhatOrbits=LevelPlan`, `WhatDest=LevelShip`, Docked=true) and still enter current Go mechDefend. The extra requirement incorrectly classifies that command as nonmechanical and permits a human assault without mechanical screening. This is a blocking command-scope/gameplay bypass.

C nuance: `source/fire.c:750–753` defines landed as `ship->whatdest==LEVEL_PLAN && ship->docked`; `source/move.c:703` calls it. Thus the initially added destination check resembles C's narrower helper, while current Go intentionally/historically has a broader actual predicate. The correction must conservatively defer everything current Go would screen, and document this C/Go discrepancy; it must not claim both helpers are identical or implement mechanical gameplay correction in this slice.

## Regression inspected

Permanent `TestGroundAssaultActorOutcomesAndRefusals/mechanical-peer` builds the real fixture's foreign armed/staffed AFV at destination; keeps it in planetary root orbit; sets WhatDest to LevelShip and DestShipNo to its root peer; sets the reciprocal peer Docked/WhatDest/DestShipNo and persists both. It then invokes real actor dispatch and expects full actor/database snapshots unchanged and no casualty/victory success text. This is a legitimate checked location context, not a deliberately broken chain that would be rejected for another reason.

Parent's `R2-mechanical-peer-before` recorded exit1, failing this exact leaf with “refusal mutated or emitted effects Attack: 20000.00 Defense: 2.00”, proving the new writer had in fact proceeded. I parsed that raw Go JSON and verified the intended assertion and parent aggregate failure, not a compilation or unrelated error.

## Correction and validation condition

Required correction: remove the extraneous WhatDest filter while retaining the already checked planetary-root orbit, Docked, correct landing coordinates, owner/diplomacy and actual retaliation predicates. No legacy landed helper or mechanical combat behavior should change. The peer case must become a whole-command refusal before random draws, mutation or successful output; aligned mutually allied AFVs must remain supported read-only witnesses.

Corrected-source independent execution and final full-source validation remain pending at creation of this report. Prior complete normal/race/long source bindings do not cover the corrected production source. Do not approve based on pre-R2 successful runs. Preserve all failed and successful execution history and independently rebind final acceptance to corrected source.

No repository edits or live operations were performed by this reviewer.

## Independent correction execution (completed)

The corrected rule removes only the extraneous WhatDest condition; planetary orbit, complete chain, Docked, staffing/ammunition/guns, retaliation, target coordinates and diplomacy remain checked. Documentation now explicitly distinguishes original C and current Go landed helpers and describes this as conservative mechanical deferral, not a mechanical gameplay fix.

Fresh independently executed command, using the established Go1.27.4/local runner with a writable temporary cache:

```
python3 /tmp/cr17c-ground-assault-implementation-evidence/run-check.py R2-independent-correction /tmp/GB-cr17c-ground-assault/go go test -count=1 -race -json -run '^TestGroundAssaultActorOutcomesAndRefusals$/(mechanical|mechanical-peer|third-party-afv)$|^TestGroundAssaultAlliedAFVIsImmutableWitness$' ./internal/game
```

Exit0, runner4.223s, package3.565s. The normal mechanical, reciprocal mechanical-peer and third-party AFV refusal leaves pass; mutually allied armed AFV positive immutable-witness case passes. Five pass nodes including the common refusal parent, no skips/failures. Source_before equals source_after in R2-independent-correction.result.json; no reviewer source changes.

**R2 source correction and focused regression: resolved.** All pre-R2 full-suite results remain historical; final complete exact-race/long-race source-bound validation and a review addendum are still required before unconditional approval. No new gameplay policy approval is necessary for refusing the already excluded mechanical operation under current Go's actual eligibility predicate.
