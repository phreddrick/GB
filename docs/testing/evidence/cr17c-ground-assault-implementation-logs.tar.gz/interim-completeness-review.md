# Interim independent source/test completeness review

This supplements, and does not replace, initial-implementation-review.md. Read-only source review by separate agent `/root/assault_phase0_review`; baseline remains b3ac84d404cc180400336f91dadb828b52c5491a. The author continued adding tests while this review ran. This is not final source/evidence acceptance.

**Verdict: no new blocking source or coverage defect identified in this pass.** Initial R1 remains corrected. Full final gates, causal negative controls and final evidence ledger remain pending.

## Real crash harness

Inspected `go/internal/game/assault_crash_test.go`. It creates only disposable fixture stores and child test executables; the child-only environment controls do not appear in production. Four world-write boundaries plus news, telegram, before-transaction, before-commit, after-commit and installed boundaries are tested for both civilian and military actors (20 named kills).

The parent waits for an actual child boundary marker, sends syscall.SIGKILL, checks the WaitStatus reports that signal (not merely an arbitrary error), rejects child race reports, reopens the same temporary file and compares complete expected record maps including bucket sequence counters. Expected new state incorporates planet, A/D races, star AP, news and defender telegram. All other rows are inherited unchanged from the prior snapshot. Confirmed commit boundaries expect the entire new set; precommit boundaries expect the original set. Restart then segment and update check actor/store agreement and retained conquest, and news count remains exactly one. This is actual process-kill coverage, not a panic simulation. No physical storage/fsync fault claim should be inferred.

These observations establish harness design; I have not independently rerun its 20 child processes in this interim review. Parent-reported executions must be checked against final logs before final approval.

## Snapshot-helper delta

Inspected full diff of `command_fixture_test.go`. Snapshot bytes remain data, while `os.OpenRoot` confines creation to the test-owned TempDir; `root.OpenFile("snapshot.db", O_WRONLY|O_CREATE|O_EXCL,0600)` prevents accidental replacement or path interpretation. File.Write and Close errors are checked; the root and read-only bbolt handle are closed. No test cases, bucket traversal, record comparison, sequence counters or PR77 immutable fixture caching were removed or weakened. No scanner suppression or lint allowance change is present.

The helper still intentionally normalizes schedule SavedAt/NextUpdate/NextSegment before comparison; this behavior predates the change. Evidence must say full record comparison **with documented schedule timestamp normalization**, rather than byte-for-byte equality of the complete database. Raw file bytes are still passed intact to bbolt and all substantive world/message/allocator fields and bucket sequences are compared.

## Added coverage inspected

The actor suite now covers private proposal ownership and stable planet/sector/race/star addresses; committed failure before installation; altered planet/A/D/star/directory identity; postinstall panic; unavailable diagnostic readback; response errors/panics; optional notification unavailable/panic; RNG preparation error; queued versus started cancellation; serialization behind an admitted command; quiesce and shutdown draining; aliases, omitted quantities and governor authority; stale planet/race/AP/ship records; hostile unload refusal. The initial faults assert no success before commit and halted no-stale-flush behavior. Complete record snapshots provide broader checks than record counts alone.

No incomplete newly migrated command was found in this pass. Explicit positive-quantity, one-step, nonmechanical sector-origin scope remains essential: negative hostile amounts, AFV mechanics, multistep assaults, hostile ship unloading and nonhostile legacy movement are not newly made transactional.

## Independently executed focused rules check

Command (Go1.27.4, local toolchain):

```
GOTOOLCHAIN=local GOCACHE=/tmp/cr17c-habitat-cache /tmp/gb-go1274-evidence/go/bin/go test -count=1 -race -v -run '^TestAssaultRules' ./internal/commandrules
```

Exit0, package1.055s. Output preserved as `interim-review-rules.out`. This is a fresh reviewer execution, unlike inspected parent logs. No skips or failures. This small focused check is not a full Go/race/long-suite run.

## Remaining final-review conditions

Review exact final sources and C parity/approved deviations; verify full regression outputs, all 20 assault kills and retained 24 population kills; independently inspect negative controls and hashes; review final normal/full race/long-race timing and all repository gates; verify no protected tooling/lint baseline/allowance weakening; reconcile documentation, PR scope and acknowledgement labels. Final acceptance cannot be based only on these source observations or the small rules run.

No repository changes, live database operation, container installation, deployment or Kubernetes operation was performed by this reviewer.
