# Independent read-only design review after owner approval

Scope: the newly approved one-step, nonmechanical **sector-origin** `move`/`deploy` hostile assault only. Source baseline `b3ac84d404cc180400336f91dadb828b52c5491a`, worktree `/tmp/GB-cr17c-ground-assault`. I read the approval transcription in `docs/testing/cr17c-ground-assault.md` and the parent's supplied exact A–E and reporting wording. The prior Phase0 reports remain historical evidence; this review does not reassert their now-resolved gameplay approval stop.

**Design verdict: feasible within existing approved storage architecture; no additional inherent schema/RNG/gameplay blocker identified for this bounded slice.** This is design review, not approval of unfinished implementation or tests. All obligations below require final source and execution review.

## Approved outcome interpretation

- Determine the human-combat winner from surviving attacker and defender residents **before absorption**. Attacker survivors with no defenders is capture; surviving defenders retain ownership and the surviving party returns; neither surviving is neutral/no winner.
- A mutually destroyed attacker cannot be recreated by absorbed bodies, even if its race has Absorb. Neither race may use absorption to convert mutual destruction into victory. This explicitly supersedes the historical C defender-elimination branch before its survivor check.
- For a surviving winning faction, draw uniformly from the **original supported body pool**, then cap the resulting absorbed civilian count at its representable remaining capacity. Do not shrink the random draw's upper bound to capacity: `min(uniform(0, bodyPool), capacity)` has a different distribution from `uniform(0, min(bodyPool, capacity))`.
- Attacker victory uses original defender civilian+military body pool; defender repulse uses attacking casualties (`oldParty - survivors`). In military victory, attacker survivors remain troops and absorbed bodies become civilians, with independent uint16 field capacities. In civilian victory they share civilian capacity. Repulse absorption adds civilians to surviving defender civilians. Bodies not represented after saturation are not live residents and must not cause overflow or extra ownership.
- Empty foreign-owned destination: no human casualty or absorption draw is needed for its zero body pool, and the positive arriving party occupies. Preserve hostile AP/admission and initial translation learning. Applying ordinary defined C attacker-win morale/Points is consistent with the approved instruction to preserve C rules except no-winner mutual destruction; do not silently reuse the earlier unapproved suggestion of zero win morale.
- Preserve C's actual extinction learning predicate `origin.popn + origin.troops + survivingParty == 0` at `source/move.c:399–405`, not Go's current omitted-party predicate. Preserve the separate defender learning when party survivors are zero. The existing C wording “You killed all of them” is historically odd; if messages are rendered from a truthful new outcome, do not accidentally change the underlying learning condition.
- Use promoted checked arithmetic for all totals, morale, Points, ownership and mobilization. `winner.Points[loser.PlayerNum]` is the actual C index, not the Go-style `-1`. Because Points has length64, player64 is an undefined C index; refuse safely where the defined index is unavailable rather than silently remapping it. Model/race identity checks and ordinary append-only limits normally keep newly enrolled players at1..63.
- C's defined casualty-scale intermediate **integer divisions** must remain integer divisions before floating arithmetic (`move.c:848–865`). Its stochastic rounding consumes a double even for a nonnegative integer, while intRand with hi<=low consumes none. Preserve that draw order in production generation and validation replay.

## Classifier and unsupported invocation safety

The classifier is security/correctness-critical, not merely routing convenience:

1. Detect hostile encounters over an entire multistep direction string before any legacy prefix runs. Friendly/neutral first step followed by hostility must be refused as a whole invocation; recognizing only the first target permits an unsafe bypass. Include numeric and letter aliases and horizontal wrap in tests.
2. Malformed coordinates/amounts, invalid direction suffixes, duplicate or excess arguments, negative leave-behind amounts and overflow must be classified before potential legacy writes. If a route can enter this supported hostile operation, invalid syntax cannot make it fall back to the unsafe writer. C negative amount means leave that many behind, not reverse movement.
3. Reject self-target/alias coordinates created by tiny planetary widths when distinct sectors are required. Validate dimensions, exact sector length, owned origin, attacker governor activity, star control, slavery, player/race map identities and destination race existence.
4. Detect **all** mechanically eligible destination AFVs from a complete checked planet ship chain, not only ships owned by the human defender. Legacy `mechDefend` (`commands_move.go:173–201`) considers any foreign AFV with retaliation strength at the landing coordinate unless reciprocal alliance exempts it. Third-party owner diplomacy is relevant. The slice may conservatively refuse a broader mechanical case, but must document that boundary rather than invoke mechanics partly.
5. Broken, dead, missing, duplicate or cyclic orbital records must fail closed; do not interpret a truncated chain as an undefended sector. Persist every relevant chain/context preimage as read witnesses inside the transaction. Witnesses are not rewritten.
6. Hostile ship-unload remains the existing deferred no-write path. AFV `walk`, transporter and other helpers are not accidentally enrolled into this transaction. Nonhostile legacy movement is not claimed fixed by this slice.

## Private proposals and exact record participation

The complete writable world set is target planet (both involved embedded sectors, global/per-owner population and troops, actual ownership transitions, MobPoints and NumSectsOwned), attacker race, defender race, and home star AP. Existing unrelated fields, ships, allocators, turn counters, schedules and commit metadata remain unchanged. Full actor-owned preimages and read-only directory/star-data/orbit/context records must be checked in the same bbolt write transaction.

Reconcile using actual before/after sector deltas for **both** sectors and owners. The origin can retain the other resident type, become neutral on departure, or regain survivors after repulse; the target can remain defender-owned, become attacker-owned or neutral on mutual death. Mobilization cannot be moved on attempted combat alone. Global live population changes by deaths plus represented absorption, not by raw requested absorption. A stale/inconsistent aggregate must be rejected rather than repairing unrelated state.

Current `commandWorkspace.race` returns its immutable `before` copy (`command_workspace.go:111–129`); it is not a writable race proposal facility. A/D need independent proposed copies and pointer-preserving installs. Race currently contains value arrays/scalars/strings, so a value copy is private for mutable fields; planet sectors need a separately owned slice. Preserve existing actor record addresses and revalidate ownership of every borrowed preimage before and after commit. Installation failure after confirmed commit must halt without any stale later flush.

## Closed transaction, records and effects

A distinct closed assault API can recompute the approved permitted output from typed request, full preimages and a bounded typed draw transcript. Validation must not consume global draws or accept unrestricted callbacks. Verify exact draw kinds/ranges/order/exhaustion; no unused suffix, random resampling, invisible retries or unbounded memory. A preimage conflict after preparation is an aborted operation, never a reason to reroll.

Exactly one existing combat-news entry plus required defender inbox messages commit atomically with the world records. Do not increment volatile groundAssaults for migrated operations; otherwise a later turn emits duplicate aggregate news. These existing buckets/helpers do not require a new schema, but new contract guards must prevent sequence overflow and overwrite:

- `appendNewsTx` (`store.go:676–692`) seeks the max key and takes Prev; if an exact max-sequence key exists, blindly calling it can compute a reused key. Inspect max-sequence and next-key availability inside the same transaction and refuse corrupt/exhausted sequence state.
- `pushTelegramTx` (`store.go:594–600`) calls NextSequence and Put. Check sequence exhaustion and next recipient key absence before appending; never overwrite a prior telegram if bucket sequence metadata is stale.
- Validate player/governor/type ranges, bounded text, exact destination and exact required news/message payloads rather than accepting arbitrary actor-provided effects. Derive recipient governor from checked star preimage. Do not expose credentials in diagnostics or complete model logging.
- Readback is diagnostic only; it must include required effects/sequence evidence when classifying visibility, but may not promote an uncertain commit to confirmed durability. WorldDigest does not independently prove these append-only messages.

Release player success text only after full committed installation. Live defender delivery is optional best effort **after** commit; use a notification-only path, not legacy `warn`/`pushTelegram`, which can issue a second independent inbox write if live delivery fails (`planet.go:1391–1415`). Committed reporting failure must never be called rollback. Unknown persistence uses the shared uncertainty guard and HALTED/no stale shutdown flush; no reopen or automatic recovery.

## Required final proof

No new production assurance follows just from this design. Final independent review must inspect exact classifiers, body-pool/saturation tests, complete storage recomputation, no counter duplication, all preimage witnesses, pointer-stable installation, news/telegram overflow and overwrite failures, fenced/maintenance/cancellation behavior, every uncertainty boundary, real SIGKILL old-or-new state including messages, segment/update/restart preservation, and unchanged earlier regressions. Lost-response retries remain unsafe without separately authorized durable command identities; atomicity is not exactly-once.

No source edits, heavyweight test runs, live operations, schema changes or production approval were performed by this reviewer. Notes were written only in the temporary evidence directory.
