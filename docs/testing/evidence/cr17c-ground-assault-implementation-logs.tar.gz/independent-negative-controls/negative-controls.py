import pathlib,json,subprocess,sys
root=pathlib.Path('/tmp/GB-cr17c-ground-assault')
p=pathlib.Path('/tmp/cr17c-ground-assault-implementation-evidence/independent-negative-controls')
rules=root/'go/internal/commandrules/assault.go';store=root/'go/internal/db/assault.go'
s=store.read_text()
controls=[
 ('capture',rules,rules.read_text().replace('to.Owner = uint8(player)','to.Owner = to.Owner'),'^TestGroundAssaultActorCR19Capture$','./internal/game','independent C-derived capture assertion'),
 ('split-write',store,s.replace('if e = s.metaFault("assault.before"); e != nil {','''if e := s.db.Update(func(tx *bolt.Tx) error { r:=prepared.writes[0];return tx.Bucket(r.bucket).Put(r.key,r.after) }); e != nil {return outcome,commandError(CommandIO)}
 if e = s.metaFault("assault.before"); e != nil {'''),'^TestAssaultStoreFailuresAndOutcomes$/assault.before/panic=false$','./internal/db','partial world/effects/sequence persisted'),
 ('missing-news',store,s.replace('seq, e := appendNewsTx(news, p.news.Type, p.news.Text)','seq, e := latest+1, error(nil)'),'^TestAssaultStoreAtomicReopen$','./internal/db','required one durable news'),
 ('missing-telegram',store,s.replace('if e := pushTelegramTx(tele, p.telegram.Player, p.telegram.Governor, p.telegram.Text); e != nil {','if e := error(nil); e != nil {'),'^TestAssaultStoreAtomicReopen$','./internal/db','required durable telegram/sequence missing'),
]
for name,source,mutated,pattern,pkg,expected in controls:
 assert mutated!=source.read_text(),name
 artifact=p/('mutant-'+name+'.go');artifact.write_text(mutated)
 overlay=p/('mutant-'+name+'.json');overlay.write_text(json.dumps({'Replace':{str(source):str(artifact)}}))
 cmd=['python3',str(p/'run-check.py'),'negative-'+name,str(root/'go'),'go','test','-count=1','-json','-overlay='+str(overlay),'-run',pattern,pkg]
 status=subprocess.run(cmd).returncode
 out=(p/('negative-'+name+'.out')).read_text()
 assert status==1 and expected in out,(name,status,'expected causal assertion absent')
 assert 'build failed' not in out and 'syntax error' not in out,name
 print(name,': detected intended defect',flush=True)
