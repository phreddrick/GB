from pathlib import Path
import hashlib,json,subprocess,collections,re,platform
p=Path('/tmp/cr17c-ground-assault-implementation-evidence');repo=Path('/tmp/GB-cr17c-ground-assault')
sha=lambda b:hashlib.sha256(b).hexdigest()
required=['accepted-source-normal-inventory','accepted-source-race','accepted-source-long-race','accepted-source-golden-mutations','accepted-source-basic-security','gates-static','manifests','growth']
for name in required:
 r=json.loads((p/(name+'.result.json')).read_text());assert r['exit_code']==0,name
 if name.startswith('accepted-source'):assert r['source_before']==r['source_after'],name+' drift'
files=subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','go','source','test/ctool','.github','test/scripts'],cwd=repo,text=True).splitlines()
manifest={n:sha((repo/n).read_bytes()) for n in sorted(set(files)) if (repo/n).is_file()}
canonical=lambda value:json.dumps(value,sort_keys=True,separators=(',',':')).encode()
final_source=sha(canonical(manifest))
for name in required:
 r=json.loads((p/(name+'.result.json')).read_text())
 if name.startswith('accepted-source'):assert r['source_after']==manifest,name+' not final source'
(p/'accepted-final-source-binding.json').write_text(json.dumps({'sha256':final_source,'files':manifest},indent=2)+'\n')
rows=[]
for f in sorted(p.glob('*.result.json')):
 r=json.loads(f.read_text());entry={k:v for k,v in r.items() if k not in ('source_before','source_after')};entry['name']=f.name.removesuffix('.result.json')
 if 'source_before'in r:
  entry.update(source_before_sha256=sha(canonical(r['source_before'])),source_after_sha256=sha(canonical(r['source_after'])),stable=r['source_before']==r['source_after'],matches_final=r['source_after']==manifest)
 else:entry['source_binding']='Not captured at execution time; historical run, not a final-source binding claim.'
 for ext in ['out','err']:
  x=p/(entry['name']+'.'+ext)
  if x.exists():entry[ext+'_sha256']=sha(x.read_bytes())
 rows.append(entry)
def counts(name):
 events=[]
 for line in (p/(name+'.out')).read_text().splitlines():
  if line.startswith('{'):
   try:events.append(json.loads(line))
   except json.JSONDecodeError:pass
 out={}
 for package in sorted({e.get('Package') for e in events if e.get('Package')}):
  tests={e['Test']:e['Action'] for e in events if e.get('Package')==package and 'Test'in e and e.get('Action')in ('pass','fail','skip')}
  done=[e for e in events if e.get('Package')==package and 'Test'not in e and e.get('Action')in ('pass','fail')]
  out[package]={'pass_nodes':sum(v=='pass' for v in tests.values()),'fail_nodes':sum(v=='fail' for v in tests.values()),'skip_nodes':sum(v=='skip' for v in tests.values()),'leaf_nodes':sum(not any(t.startswith(n+'/') for t in tests) for n in tests),'package':done[-1] if done else None,
    'assault_SIGKILL_leaves':sum(t.startswith('TestGroundAssaultRealProcessCrash/') and t.count('/')==2 for t in tests),
    'population_SIGKILL_leaves':sum(t.startswith('TestPopulationRealProcessCrash/') and t.count('/')==2 for t in tests)}
 return out
normal=counts('accepted-source-normal-inventory');long=counts('accepted-source-long-race')
race_game=re.search(r'^ok\s+github.com/phreddrick/GB/go/internal/game\s+([\d.]+)s', (p/'accepted-source-race.out').read_text(),re.M);assert race_game
ledger={'unit':'CR-17C #41B / CR-19 approved one-step nonmechanical ground movement only','baseline':'b3ac84d404cc180400336f91dadb828b52c5491a','branch':'feature/cr17c-ground-assault','worktree':str(repo),'toolchain':subprocess.check_output(['/tmp/gb-go1274-evidence/go/bin/go','version'],text=True).strip(),'GOTOOLCHAIN':'local','platform':platform.platform(),
 'final_source_sha256':final_source,'source_manifest_artifact':'accepted-final-source-binding.json','executions':rows,'required_final_acceptance':required,'normal_counts':normal,'long_race_counts':long,'exact_race_game_seconds':float(race_game.group(1)),
 'notes':['Each bash -c set -e result0 confirms every listed subcommand completed.','Standalone early failures and corrected fixture errors are preserved in early-attempts.md and raw run records.','Pre-R2 full-suite passes and test-only source drift are historical evidence, not final acceptance.','Go JSON counts include parent test nodes; leaves are counted separately. Crash child entry is not a SIGKILL boundary.','Final tests use isolated worlds; no source C or protected gate/allowance changes.','General fixture snapshots normalize three schedule timestamps; new crash assertions separately compare raw commit/schedule/maintenance/universe bytes.','A SIGKILL old/new oracle is not physical disk failure/fsync fault proof. No uncertain handle is reopened as recovery.','All old #41A tests and24 SIGKILL boundaries remain unchanged; no full #41/#51/#38 issue closure.','Offline manifest runner is unchanged and internally sets GOTOOLCHAIN=auto for its pinned helper only; application/tests/scanner invocations are local Go1.27.4.'],
 'negative_controls':{'capture':'negative-capture','split-write':'negative-split-write','missing-news':'negative-missing-news','missing-telegram':'negative-missing-telegram','expected':'Each exited1 with the specific intended assertion, not a build error. Independently repeated in independent-negative-controls/.','R2_mechanical_peer':'R2-mechanical-peer-before failed by actually committing assault; corrected run passes with exact existing Go mechanical refusal.'},
 'format_impact':'NONE; existing world records and news/telegram buckets, unchanged CR18 kinds/schema; no command IDs or outbox',
 'hosted_ci':'Created after this pre-commit ledger; actual run URL/results reported in PR and final response.'}
(repo/'docs/testing/evidence/cr17c-ground-assault-implementation-validation.json').write_text(json.dumps(ledger,indent=2)+'\n')
print('final source',final_source)
print('exact race game',ledger['exact_race_game_seconds'])
for label,c in [('normal',normal),('long',long)]:
 print(label,'nodes',sum(x['pass_nodes']for x in c.values()),'skips',sum(x['skip_nodes']for x in c.values()),'game',c['github.com/phreddrick/GB/go/internal/game']['package']['Elapsed'])
