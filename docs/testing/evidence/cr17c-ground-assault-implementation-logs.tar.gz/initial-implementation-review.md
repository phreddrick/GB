# Initial independent implementation source review

Scope: first implementation of the owner-approved one-step nonmechanical sector assault, baseline `b3ac84d404cc180400336f91dadb828b52c5491a`. Read-only reviewer `/root/assault_phase0_review`; no repository edits. Reviewed current `commandrules/assault.go`, `db/assault.go`, `game/assault_command.go`, dispatch intercept, existing model/workspace/combat/persistence helpers, and initial rule/database/actor tests. Production files were still being developed by the author during this review; final source/evidence review remains required.

## Verdict

**CHANGES REQUESTED initially: R1 existing-news overwrite. R1 correction independently validated; no additional blocking source defect identified in this first pass.** This is not final acceptance: crash tests, installation/lifecycle cases, complete C edge fixtures and full gates were still pending when review began.

## R1 — malformed news key can overwrite an existing durable news entry (blocking; corrected)

Initial `writeAssaultEffects` checked only an exact MaxUint64 news key before calling the legacy `appendNewsTx`. That helper finds a last stream key but defaults sequence to0 if the key length is not9. Reproducing input: existing combat `NewsKey(NewsCombat,1)="prior"`, plus a lexically greater malformed key `append(NewsKey(NewsCombat,2),0)`. The helper selects the malformed key, computes1, and overwrites the old valid sequence1 while committing an otherwise complete assault. Thus the first implementation could destroy unrelated durable news.

Reported to author before edits. Author corrected the closed operation rather than broadening/changing the legacy helper: validate each current-stream key's exact length, nonnil value and nonzero sequence; compute the true latest; reject exhaustion or occupied next key; require helper return exactly latest+1. The new permanent `TestAssaultStoreStaleAndClosedContract/news-malformed` requires whole-transaction rollback and unchanged prior records.

I independently constructed a disposable compiler-overlay regression in `news-overwrite-review_test.go` that inserts those two keys, runs `CommitGroundAssault`, then checks original sequence1 still contains `prior`. First execution failed before compilation because the default cache path is read-only in this review sandbox; `news-overwrite-review.out` preserves that infrastructure failure. No original unsafe implementation runtime failure is claimed from that failed invocation; the initial defect was established by source inspection and the exact deterministic helper path.

After correction, I independently executed both my overlay regression and the author's permanent regression with actual Go1.27.4 and `GOTOOLCHAIN=local`, temporary writable cache. Command:

```
GOTOOLCHAIN=local GOCACHE=/tmp/cr07a-cache /tmp/gb-go1274-evidence/go/bin/go test -count=1 -v \
  -overlay=/tmp/cr17c-ground-assault-implementation-evidence/news-review-overlay.json \
  -run '^TestReviewAssaultPreservesExistingNews$|^TestAssaultStoreStaleAndClosedContract$/news-malformed$' ./internal/db
```

Exit0, package0.014s. The independent probe observed `NOT_COMMITTED` / `CORRUPT_COMMAND_RECORDS`; both named regressions passed. Output: `news-overwrite-correction-review.out`. The overlay creates only a virtual test file in the test binary and does not modify repository sources.

## First-pass verified design/source properties

- The classifier scans the entire direction string before any legacy prefix; it refuses multistep hostility and invalid suffixes before mutation. Both dispatch verbs share this interception. A one-step hostile command does not reach legacy `movePopn` writes. Explicit quantities are positive uint16 in this approved slice; unsupported signed hostile amounts are refused rather than falling back. Ordinary nonhostile movement remains legacy and is not claimed transactional.
- Pure validation checks active attacker governor/star control, owned origin, foreign valid defender, map dimensions/indices, exact accounting preimages, AP and eligible mechanical exclusion. Planet chain entries require unique IDs, live matching planetary location and complete membership. Third-party ship-owner race witnesses are included. The AFV exclusion follows non-allied foreign landed armed/retaliatory AFVs at the destination; it does not inspect only the human defender's ships.
- Pure rules own private sector slices and race/star value copies. Outcome precedes absorption; mutual produces no winner or resurrection. Absorption samples the original body pool then saturates capacity. Integer divisions in casualty scale, C stochastic rounding draw behavior, defined C morale/Points index and origin+surviving-party extinction learning are represented. Empty foreign sectors skip casualty draws and use the approved occupation path. Promoted sums and checked widths prevent wrapped population/points/morale/AP.
- The typed transcript validates kinds, bounds, unused fields, finite fractions, draw order and exact exhaustion. Storage replays without fresh randomness. Production preparation uses isolated uniform secure draws; global RNG helpers/turn state are not changed. No retry/reroll or durable replay claim is introduced.
- Storage is a separate closed operation. Complete planet, both races, star/AP and every ship/third-party race witness are serialized and compared inside one bbolt write transaction; pure recomputation occurs again after those preimages match. No unchecked partial entity write, allocator, schema, turn metadata or new commit kind is introduced.
- Required durable news and defender inbox effects are derived from checked input/outcome/time and written inside the same transaction; no migrated volatile assault counter increment is present. Telegram exhaustion and stale bucket-sequence/overwrite are refused; corrected news guard addresses R1. Readback includes appended message records as diagnostic visibility and does not turn uncertainty into durability.
- Actor preimages remain private. Confirmed persistence precedes installation; planet, sector slice, A/D race and star actor addresses are preserved through assignments. Ownership checks happen together before installation. Uncertain outcome installs nothing; confirmed-commit reporting errors still install committed state and halt; HALTED suppresses stale shutdown flushing through existing policy.
- Player success is buffered until installation. Optional live defender notification uses registry notification only, avoiding legacy warn/pushTelegram's second independent inbox write. Lost-response operation is not automatically retried and is not exactly-once.

## Remaining final-review obligations

This first pass does not prove unexecuted tests or all intended semantics. Final review must verify real-process SIGKILL boundaries and old-or-new complete state including message sequences; complete casualty/absorption/counter/morale and authority matrices; actor install/delivery failures; stale orbit witnesses; concurrent admission, cancellation/draining/maintenance/fencing; segment/update/restart safety; preservation of accepted population24-crash and earlier regressions; exact final document/validation ledger and full local gate results. Explicitly document the bounded positive-quantity hostile grammar, player64 undefined Points-index refusal, nonhostile legacy limitation and excluded AFV/multistep/ship assaults.

No live database, Kubernetes, deployment or image operation was performed. No independent final implementation approval is claimed.
