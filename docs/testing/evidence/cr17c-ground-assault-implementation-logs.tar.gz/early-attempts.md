# Early attempts not captured as standalone runner logs

These are preserved from the execution transcript; no fabricated timings/source
bindings are assigned. Later named runner artifacts preserve fresh actual runs.

1. Initial compile invocation from repository root: `go test ./internal/commandrules ./internal/db -run '^$'` exited1 (`go.mod file not found`). Corrected to module cwd / `go -C go`.
2. A multiline test-file construction accidentally used module cwd while paths still began `go/`: Python/FileNotFoundError and shell `No such file or directory`. Its final `go test` reported `[no tests to run]` and compound status0; this is NOT a passing execution of the missing tests. Repeated file construction from root, then actually executed tests.
3. Initial db test compile exited1: PutMaintenance requires a pointer; record uses SetAt/Quiesced, not EnteredAt. Fixture corrected; actual db tests then passed.
4. Initial actor test compile exited1: maps cannot use ==/!= except nil. Full record comparisons corrected to reflect.DeepEqual.
5. A temporary bulk edit replacing morale helper arguments also changed two integer casualty-strength multiplications to int×uint8. Compile failed; the two int widenings were immediately restored before acceptance execution.

# Captured failed attempts and corrections

- initial-focused: wrong test race initialization appended race2 to the fixed64-slot AllRaces array instead of assigning slot1. This was fixture setup failure, not evidence that rejecting every assault was acceptable. Corrected explicit slots, retained full initial logs.
- focused-fixture-correction: post-Stop snapshot attempted actor opTest; actor had exited. Snapshot now reads only the private quiescent fixture file after stopped closes and compares all rows/sequences. No uncertain handle is reopened or cleared.
- actor-additional-boundaries / inventory-final-normal / race-full / golden-mutations: six southern-direction aliases used originY1 on a two-row fixture and panicked in test setup. Choose originY0 for southern aliases and Y1 for northern aliases. All16 aliases remain tested; no assertions/timeouts/cases removed. Full normal/race/mutation reruns follow.
- lint-first:24 new findings, no stale baseline entries. Narrowing conversions replaced by explicit checked-width operations; tagged switches corrected. No allowances added.
- lint-corrections: only G703 on os.WriteFile in the existing snapshot reader remained. The pinned analyzer treats all WriteFile arguments as traversal sinks, including inspected database bytes. Snapshot file creation now uses an exclusive constant filename under os.Root/File.Write, keeping arbitrary bytes out of pathname APIs. Contents, mode0600, private TempDir, error checks, complete rows and bucket sequences remain intact. No scanner suppression/baseline/gate modification.
- lint-final: two new uint32→uint16 AP-fixture conversions. Fixture quantities now use their actual uint16 storage width; no values/cases changed. Rerun uses unchanged lint policy.

Initial review R1 discovered malformed news keys could make the existing allocation
helper overwrite seq1. New operation now validates current-stream key shapes,
sequence exhaustion and exact next-key absence inside the transaction, and checks
returned allocation identity. The permanent news-malformed regression plus the
reviewer's independent reproduction passed after correction. Original findings,
cache-denied reviewer attempt and correction executions are retained separately.
