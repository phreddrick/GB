# Independent final review — issue #76 game race-suite runtime

Verdict: **APPROVE implementation and local acceptance evidence; hosted CI remains pending.** This is a separate read-only source/test/evidence review. No reviewer repository edits, production operations, other-worktree changes or external messages occurred. The reviewer does not claim to have independently rerun the author's complete suites; the fresh independent execution is stated below.

## Scope and resolved finding

Final test source is the new immutable command-fixture image helper and exactly three constructor substitutions: factory, habitat and exploration dump. Production code, C, race flags, default package timeout, existing scheduling, assertions, all 24 population SIGKILL scenarios, protected gates/workflows and allowances remain unchanged. Real actor dispatch/persistence/failure/turn/restart tests remain the subjects under test; actual enrollment/bootstrap acceptance retains its original initialization path. No maintainer acknowledgment label is required by the unchanged growth gate.

The cache builds the prerequisite once through real initialization and confirmed trusted enrollment. It exports immutable string bytes/value fields and pure policy closures only. Each fixture has a fresh file/Store/actor/config/log/policy/model graph, and actor-local directories are copied by value. Controlled snapshot capture is serialized on the exclusively owned disposable actor, before cleanup writes; it is explicitly not a live-store backup mechanism. Recreated schedules use existing production constructors and differ only in the three current timestamps, with zero counters and interval correctness independently checked.

R1 from `review-code.md`: complete-equivalence test originally omitted bbolt bucket sequences. **RESOLVED**: bucket presence now records Sequence(), alongside every key/value, preserving allocator/free-list evidence. Eight parallel mutation-isolation cases and independently regenerated/enrolled world/placement comparison are retained. No remaining source-level correctness or test-weakening blocker identified.

## Fresh independent execution

Go1.27.4, GOTOOLCHAIN=local, GOMAXPROCS=4:

`go test -count=2 -race -json -run '^TestCommandFixture' ./internal/game`

Explicit process timeout120s; exit0 in6.698s;20 passing test-node executions/4 top-level executions. Both passes exercise complete equivalence and eight-way parallel isolation. Stderr empty. All four source hashes were captured before/after and remained unchanged. Result/output details are in `independent-fixture-race.result.json`.

Output SHA-256: `07dfecb5caee95ae5b19707cefc8022223ca7186c1ba4994b8a9a5265bc62236`.

## Author evidence independently inspected

Parsed complete raw JSON logs and compared test identities, rather than relying solely on summary files:

- Baseline profiled game race:1297 passing nodes/223 tops,502.025s package. Profile is intentionally not an exact unprofiled hosted comparison; CPU cumulative percentages overlap.
- Unchanged exact full CI race command: game321.246s. Independent cold-build-cache run: game327.055s. Both exit0 under the unchanged600s package limit.
- Final long complete race:4605 passing nodes/464 tops; zero test skips, game310.753s; whole-command317.103s. Package-level skips represent packages without tests, not skipped test cases.
- Every one of1297 original game passing test identities retained, exactly10 new equivalence/isolation identities added; independently recomputed against raw logs.
- Population coverage:345 passing nodes across rules/db/game,213 game nodes, all24 real SIGKILL leaves. Count3 representative execution has72 SIGKILL leaves and669 passing node executions, confirming repeats rather than missing cases.
- Final normal suite4603 passing nodes/462 tops; two pre-existing production-timing long tests skip without GB_LONG_TESTS, and both execute in the complete long race run.
- Original split-writer mutation, injected solely via temporary source overlay, exits1 with all8 atomic-pair leaves and2 accounting leaves failing. Runtime optimization therefore did not disable the regressions that detect the original defect.

All33 check result records inspected:32 exit0, plus the deliberate original-defect mutation's expected exit1. Actual outputs confirm15 golden mutations; gate helper tests; C fixtures; inventory; lint1000 matched/new0/stale0; growth labels[]/no protected changes;21 offline manifest resources valid;188 workflow tests and17 policy checks; build/vet/format/modules/diff; strict govulncheck0 affected,17 module advisories in uncalled paths (no suppression).

Raw logs inspected for bcrypt/JWT-shaped secrets found none. The final evidence package still requires a manifest/hash check after packaging; do not substitute an archive hash for actual test execution.

## Runtime claim and limits

Both hosted failures hit cumulative600s package alarms while active population groups were only4–15s old. The targeted immutable prerequisite avoids repetitive real enrollment/JSON setup in command-only tests without removing command scenarios. Multiple complete unchanged-budget local runs now leave material headroom. This supports the bounded correction; it cannot guarantee a fixed runtime on every future runner. Hosted seven-job CI must actually execute after push and is not pre-approved by this report.

No claim that CR-17/CR-11/CR-13/CR-19/CR-20 or public registration is complete. No new durability, exactly-once or rollback-security guarantee. #41 and #51 remain open. No merge, deployment, image publication, Kubernetes or live-game DB operation authorized or performed in this review.

## Reviewed final source hashes
- `go/internal/game/command_fixture_test.go`: `4e191057c8c83d23c69abc14c873987a42b0d3ae8e89fe302c8f35dbe05138cb`
- `go/internal/game/command_records_test.go`: `8ddb2ab0c5e2f57e627d56234b30baa342bb56e5d6a21e146e67f9b1ee002972`
- `go/internal/game/factory_staging_test.go`: `c53ef1c0a07a32d44eaf907896a68a6a47b663f152a10f969fc31242c1f20522`
- `go/internal/game/habitat_staging_test.go`: `a8f2a1cea96f8d2530f8233d747ab7ee6710c07d217f4a4c91fd74f05a42d6d5`

Population crash harness unchanged SHA-256: `aa341768b71854a0e64ae8a5281642eb9da714adcf40f8e7269cd44af4f8cd26`.
