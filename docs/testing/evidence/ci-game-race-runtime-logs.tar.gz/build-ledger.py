import gzip,hashlib,io,json,pathlib,tarfile
root=pathlib.Path('/tmp/gb-ci-game-race-evidence')
repo=pathlib.Path('/tmp/GB-ci-game-race-runtime')
out=repo/'docs/testing/evidence'
out.mkdir(exist_ok=True)
hashof=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results=[]
for p in sorted(root.glob('*.result.json')):
 r=json.loads(p.read_text());r['name']=p.name[:-12]
 r['expected_exit_code']=1 if r['name']=='original-defect-mutation' else 0
 r['accepted']=r['exit_code']==r['expected_exit_code']
 for suffix in ['out','err']:
  f=root/(r['name']+'.'+suffix)
  if f.exists():r[suffix+'_sha256']=hashof(f)
 if r['name'] in ['fixture-correctness','full-normal','full-race-original']:
  r['source_note']='Preliminary execution before final new-test assertion strengthening; final source is exercised by cold-cache, long race and final normal runs.'
 if r['name']=='baseline-game-race':
  r['source_note']='Unmodified baseline compiled before edits; profiling overlay run overlapped briefly. Profiling flags and package-only scope differ from original unprofiled CI command.'
 results.append(r)
assert all(r['accepted'] for r in results)
# Keep raw logs (including intentional failures), profiles, original downloaded
# job evidence, instrumentation overlays, review history and reproduction scripts.
files=sorted(p for p in root.iterdir() if p.is_file() and p.suffix in ['.out','.err','.json','.log','.cpu','.mem','.md','.py','.go'])
archive=out/'ci-game-race-runtime-logs.tar.gz'
with archive.open('wb') as dst:
 with gzip.GzipFile(filename='',mode='wb',fileobj=dst,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for p in files:
    b=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(b);info.mtime=0;info.mode=0o600
    tar.addfile(info,io.BytesIO(b))
ref=json.loads((root/'final-test-source-hashes.json').read_text())
assert all(hashof(repo/p)==h for p,h in ref.items())
ledger={
 'issue':76,'related_open_issues':[41,38,51],
 'baseline':'5ac223db8fa4127267f5338cafd425bb491f1d5c',
 'toolchain':'go1.27.4','GOTOOLCHAIN':'local',
 'environment':'Linux amd64, 16 logical CPUs, igor; all test data disposable. Four-GOMAXPROCS runs are scheduler-limited, not dedicated hosted-runner equivalents.',
 'test_source_sha256':ref,
 'baseline_source_sha256':json.loads((root/'baseline-source-hashes.json').read_text()),
 'coverage':json.loads((root/'coverage-comparison.json').read_text()),
 'negative_control':json.loads((root/'mutation-effectiveness.json').read_text()),
 'checks':results,
 'preserved_probe_failure':{'command':['go','tool','pprof','-top','-cum','baseline-game.cpu'],'exit_code':1,'diagnostic':'go: no such tool pprof','resolution':'Successful baseline-pprof check uses go run cmd/pprof from the pinned toolchain sources.'},
 'archive':{'file':archive.name,'sha256':hashof(archive),'bytes':archive.stat().st_size,'files_sha256':{p.name:hashof(p) for p in files}},
 'hosted_status_at_preparation':'Not part of local execution evidence; report exact PR HEAD, run and all seven checks separately. Post-merge acceptance requires owner authorization and fresh master CI.',
 'acknowledgment_labels':'None: no protected tooling, lint baseline, inventory or allowances changed.',
}
(out/'ci-game-race-runtime-validation.json').write_text(json.dumps(ledger,indent=2)+'\n')
print('checks',len(results),'archive bytes',archive.stat().st_size,'sha256',hashof(archive))
