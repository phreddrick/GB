import os, subprocess, sys, json, time
from pathlib import Path
root=Path('/tmp/gb-ci-game-race-evidence')
name,cwd,*cmd=sys.argv[1:]
env=os.environ.copy()
env.update(GOTOOLCHAIN='local',GOCACHE='/tmp/cr17c-habitat-cache',TMPDIR='/tmp/GB-ci-game-race-runtime/test/ctool/obj/tmp')
env['PATH']='/tmp/gb-go1274-evidence/go/bin:/tmp/claude-1026/-home-steve-workspace-GB/ee9ebf80-502c-4ecf-ad67-736e8673c55c/scratchpad/p2c/bin:'+env['PATH']
t0=time.time()
with (root/(name+'.out')).open('wb') as out,(root/(name+'.err')).open('wb') as err:
 try:
  status=subprocess.run(cmd,cwd=cwd,env=env,stdout=out,stderr=err,timeout=1800).returncode
 except subprocess.TimeoutExpired:
  status=124
rec={'command':cmd,'cwd':cwd,'go':'go1.27.4','GOTOOLCHAIN':'local','started_unix':t0,'elapsed_seconds':round(time.time()-t0,3),'exit_code':status}
(root/(name+'.result.json')).write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps({'check':name,'exit_code':status,'elapsed_seconds':rec['elapsed_seconds']}))
sys.exit(status)
