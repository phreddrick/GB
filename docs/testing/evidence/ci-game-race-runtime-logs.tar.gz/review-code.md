# Independent implementation review — issue #76

Separate read-only reviewer, baseline `5ac223db8fa4127267f5338cafd425bb491f1d5c`. Review covers new `command_fixture_test.go` and the three existing helper substitutions in `command_records_test.go`, `factory_staging_test.go` and `habitat_staging_test.go`. No reviewer repository edits or heavy test runs during author profiling.

## Design findings

The cache builds a real deterministic initialized universe and first God enrollment using existing `newEnrollmentActor`/`EnrollTrusted` once; only an immutable bbolt image string, value-only Directory arrays, value PlacementRecord, immutable policy callbacks and a diagnostic actor JSON string escape. Each consumer writes a new 0600 temporary file and opens its own Store/config/actor/log/policy. No bbolt mmap, Store uncertainty state, model pointer/slice, callback test hook or registry is borrowed from another actor. Enrollment/bootstrap tests retain their original helper unchanged.

The image is read synchronously while its exclusively owned seed actor executes opTest. No external writer exists for that seed; scheduler/stop are blocked by the same actor. This narrow fixture condition makes raw-file capture coherent; the comment correctly forbids treating it as a live-store backup API. Snapshot occurs after confirmed real enrollment and before ordinary seed shutdown writes.

Each clone resets only the three fresh schedule timestamps using production `freshSchedule`/`scheduleRecord` before opening the actor. Zero turn/segment counters, settings and commit metadata remain unchanged. This reproduces original per-fixture deadline behavior instead of allowing cached deadlines to expire across a long/count/shuffle run. New equivalence assertions bound the construction anchor between actual before/after times and retain exact interval/counter checks.

The added tests compare all actor-world/directories to the genuine enrolled seed and independently regenerate/enroll a fresh actor. The PlacementRecord comparison excludes only CreatedAt and its resulting RecordHash; all other historical identities compare exactly. Eight parallel isolation cases mutate nested planet sectors/Info, ship, star, race governor, star data, directory, hook, policy, config and fence in one fixture while checking existing and newly created other fixtures remain identical to seed. This is substantive isolation coverage.

Only the prerequisite setup changes in the three existing command helpers. Their command dispatches and every existing assertion are unchanged; all population real-process crash code remains byte-identical, including four variants × six SIGKILL boundaries. No production application file, original C, gate script, workflow, baseline, allowance, timeout or race flag is changed.

## R1 — allocator sequence comparison gap (test evidence, correction requested)

`commandFixtureRecords` enumerated bucket names and all key/value records but did not include `Bucket.Sequence()`. This matters because ship/commodity free-list appenders call NextSequence, and enrollment allocator fingerprints include Sequence. The byte-copy implementation itself retains these values; this is not an observed data-loss defect. However, the claimed complete allocator-equivalence test should include every bucket sequence, as the existing db enrollment snapshot test does. Author notified. Final disposition pending verification of correction.

## Profile evidence inspected

Author's baseline result is exit 0 with Go1.27.4/GOTOOLCHAIN=local and unchanged race command; external elapsed508.526s. CPU profile duration500.39s, total CPU samples655.66s; EnrollTrusted151.15s cumulative (23.05%), JSON v2 Unmarshal165s cumulative (25.17%). These overlapping CPU percentages must not be added or confused with wall time. They support targeting repeated enrollment setup rather than generation (~0.5ms in author instrumentation). The old hosted logs show cumulative600s package timeouts. No claim of independent execution of this profile is made.

## Provisional conclusion

Bounded optimization is correct in design and preserves command test strength. No blocking runtime/security defect found. R1 should be completed for accurate full allocator evidence. Final approval requires final unchanged test counts/SIGKILL evidence, actual validation logs, and independent focused execution when author indicates it will not perturb measurements.

## Source hashes at this review
- `go/internal/game/command_fixture_test.go`: `7e4cb357c6560121f0e776ad7f23a25176d460ca6fbc7a4e9e2985f61d3688ce`
- `go/internal/game/command_records_test.go`: `8ddb2ab0c5e2f57e627d56234b30baa342bb56e5d6a21e146e67f9b1ee002972`
- `go/internal/game/factory_staging_test.go`: `c53ef1c0a07a32d44eaf907896a68a6a47b663f152a10f969fc31242c1f20522`
- `go/internal/game/habitat_staging_test.go`: `a8f2a1cea96f8d2530f8233d747ab7ee6710c07d217f4a4c91fd74f05a42d6d5`
- `go/internal/game/population_crash_test.go`: `aa341768b71854a0e64ae8a5281642eb9da714adcf40f8e7269cd44af4f8cd26`
