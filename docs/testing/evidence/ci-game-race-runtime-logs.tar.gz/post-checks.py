import subprocess,sys
root="/tmp/gb-ci-game-race-evidence"
repo="/tmp/GB-ci-game-race-runtime"
checks=[
("full-normal-final",repo+"/go",["go","test","-count=1","-json","./..."]),
("representative-population",repo+"/go",["env","GOMAXPROCS=4","go","test","-count=3","-race","-json","-run","^TestPopulation|^TestCommandFixture","./internal/game"]),
("build",repo+"/go",["go","build","./..."]),
("format",repo+"/go",["bash","-c",'test -z "$(gofmt -l .)"']),
("vet",repo+"/go",["go","vet","./..."]),
("modules-verify",repo+"/go",["go","mod","verify"]),
("modules-tidy",repo+"/go",["go","mod","tidy","-diff"]),
("c-fixtures",repo,["make","-C","test/ctool","check"]),
("inventory",repo,["test/scripts/inventory-check.sh"]),
("golden-mutations",repo,["test/scripts/golden-mutations.sh"]),
("growth",repo,["test/scripts/growth-gate.sh","5ac223db8fa4127267f5338cafd425bb491f1d5c"]),
("golden-selftest",repo,["test/scripts/golden-mutations-selftest.sh"]),
("lint-selftest",repo,["test/scripts/lint-gate-selftest.sh"]),
("approval-selftest",repo,["test/scripts/gate-approval-selftest.sh"]),
("offline-manifests",repo,["deploy/kustomize/tests/run.sh"]),
("workflow-tests",repo,["python3","-m","unittest","discover","-s",".github/scripts","-p","test_*.py","-v"]),
("workflow-policy",repo,["python3",".github/scripts/workflow_policy_check.py"]),
("actionlint",repo,["actionlint","-no-color"]),
("shellcheck",repo,["bash","-c","shellcheck -S warning .github/scripts/*.sh"]),
("govulncheck",repo+"/go",["go","run","golang.org/x/vuln/cmd/govulncheck@v1.9.0","./..."]),
("diff-check",repo,["git","diff","--check"]),
]
for name,cwd,cmd in checks:
 result=subprocess.run([sys.executable,root+"/run-check.py",name,cwd,*cmd])
 if result.returncode: sys.exit(result.returncode)
