# Independent initial runtime review — issue #76

Reviewer: separate read-only `/root/population_independent_review` agent. Source: `/tmp/GB-ci-game-race-runtime`, baseline `5ac223db8fa4127267f5338cafd425bb491f1d5c`. No repository or other worktree edits; no heavyweight tests run during the author's profiling.

## Hosted evidence

The earlier successful job 131033917898 reports normal game package 43.040s and race game package 419.166s. Failed job 131043680806 reports normal 57.819s, then default Go package timeout at 600.073s. Failed retry 131274014130 reports normal 60.667s, then the same package timeout at 600.064s. The failed dumps show currently active population top-level groups only 4–15s old and their individual scenarios only 0–1s old. This is evidence of cumulative package-budget exhaustion, not a ten-minute population scenario or proof of a deadlock. The passed/failed normal runtimes also demonstrate significant runner-speed variation; a marginal local pass does not establish hosted headroom.

Raw-log SHA-256:

- hosted-131033917898.log: ace1d49615d8d9dbfd087f7138059d7f43193e3a6e34294d43151baa872de1fd
- hosted-131043680806.log: edfdc6b9520d327dd891888eb8cab1c48401dd33f06481f8e3e73e592913cfb4
- hosted-131274014130.log: c8150606313e993d481153e22209cd6cbdd17732295ec9ff9ad061dfc306a981

The timeout stacks include live JSON decoding and real actor enrollment/fixture initialization. These snapshots alone do not quantify CPU dominance; author's full profile is needed.

## Fixture architecture

`newEnrollmentActor` creates its own temp DB/config/log/actor, regenerates a deterministic 4-star/8-planet universe, normalizes sectors, writes it through real `PutUniverse`, and configures trusted policy. `newFactoryFixture` then performs real `EnrollTrusted` for the first God race and adds the factory. Cargo, population, habitat and telescope fixtures repeatedly build on it. Repeating real startup/enrollment/JSON/persistence is substantial setup not intrinsic to each later command assertion.

Credential generation is already cached behind sync.Once at production DefaultCost. `preparedEnrollmentCredentials` parses bcrypt cost/encoding; it does NOT bcrypt-compare every enrolled fixture. Do not assume credential hashing dominates fixture creation or lower bcrypt work to optimize it.

The author's private instrumentation output, inspected read-only, reports normalized-universe generation about 0.46–0.54ms, PutUniverse about 22ms, actor open about 43–49ms and enrollment about 305–317ms for representative warmed scenarios. These are author-run measurements, not my fresh execution. Consequently universe-only caching is safest but appears unlikely by itself to resolve the runtime gap. Whole-package profiling should decide.

## Optimization disposition

1. An immutable deterministic normalized-universe JSON cache is safe in principle if sync.Once publishes sealed bytes, each fixture decodes into a fresh Universe graph and no cached bytes or pointers escape. Keep each DB, actor, config, timestamps, policy, registry and real enrollment independent. Add equivalence against freshly generated/normalized data and deliberate mutation-isolation checks for all nested slices. The Universe contains StarData pointer and slices of Star/Planet pointers; shallow copies are insufficient. This optimization does not bypass persistence tests, but current timing suggests limited gain.
2. Sealed pre-enrolled fixture DB bytes can provide a larger bounded optimization for command-only fixtures, but require more careful proof. Build the image once through real initialization and enrollment, cleanly stop and close before reading bytes, and create a fresh private file/DB handle/actor per consumer. Never copy an open mmap database or share State/Store/model pointers. Verify full-world/placement/allocator/commit metadata equivalence and deep isolation; retain real enrollment initialization for tests whose subject is enrollment/bootstrap/fault handling. Avoid importing a committed image into tests expecting uninitialized state. Reopening/resetting a handle to bypass uncertainty remains prohibited.
3. Safer than universal pre-enrolled replacement is a separate command-fixture helper using the sealed image only for later command tests. Keep `newEnrollmentActor` and all actual enrollment acceptance tests on the existing genuine setup path. Preserve every command dispatch, preimage, atomicity, failure, SIGKILL, actor installation, turn, restart and output assertion.
4. No timeout increases, skipped cases, altered assertions, weakened race flags, reduced bcrypt validation, modified gates or omitted crash scenarios are justified. All 24 population SIGKILL scenarios must still execute. A fixture optimization should preserve counts and include cache provenance/isolation regressions.

## Initial verdict

No source-level blocker to immutable private fixture caching was identified. Universe-only cache is low risk but probably insufficient; a tightly scoped sealed command-world image is conditionally acceptable after equivalence/isolation and unchanged command/crash coverage are demonstrated. This is a design review, NOT final implementation approval or an independent claim that tests passed.

### Controlled open-seed snapshot clarification

Store exposes no existing backup interface. A generic backup must use a transaction-consistent copy or a closed file; however, this proposed test-only seed has a narrower provable exclusion boundary. Reading its file synchronously inside the sole actor's opTest callback can be coherent when the seed/store is exclusively owned, no hook or other goroutine can write the store, initialization/enrollment have finished successfully, and scheduled turns/shutdown cannot execute until that callback ends. bbolt itself has no autonomous application writer. This must remain an explicitly controlled fixture implementation, never a production/live-backup recipe. Snapshot before ordinary cleanup avoids adding a shutdown commit absent from original setup. Compare full logical contents before/after restore; do not rely merely on file hashes or race absence.
